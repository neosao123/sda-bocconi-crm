<!--main table view-->
@include('pages.tasks.components.table.table')
