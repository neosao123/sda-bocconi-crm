<?php

namespace App\Http\Requests\Admin\Library;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SmBookRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        // return [
        //   'book_title' => "required|max:200",
        //   'book_category_id' => "required",
        //   'subject' => "required",
        //   'quantity' => "sometimes|nullable|integer|min:0",
        //   'book_number' => "sometimes|nullable",
        //   'isbn_no' =>  "sometimes|nullable|unique:sm_books,isbn_no|different:book_number",
        //   'publisher_name' => "sometimes|nullable",
        //   'author_name' => "sometimes|nullable",
        //   'details' => "sometimes|nullable",
        //   'book_price' => "sometimes|nullable|integer|min:0",
        //   'rack_number' => "sometimes|nullable",
        // ];

        // Determine if this is an update or a create operation
        $bookId = $this->route('id');

        // Basic rules for both create and update
        $rules = [
            'book_title' => "required|max:200",
            'book_category_id' => "required",
            'subject' => "required",
            'quantity' => "sometimes|nullable|integer|min:0",
            'book_number' => "sometimes|nullable",
            'isbn_no' => [
                'sometimes',
                'nullable',
                'unique:sm_books,isbn_no',
                'different:book_number',
            ],
            'publisher_name' => "sometimes|nullable",
            'author_name' => "sometimes|nullable",
            'details' => "sometimes|nullable",
            'book_price' => "sometimes|nullable|numeric|min:0|gte:0",
            'rack_number' => "sometimes|nullable",
        ];

        // Additional rule for create operation to ensure isbn_no is unique
        if ($bookId) {
            $rules['isbn_no'] = [
                'sometimes',
                'nullable',
                'unique:sm_books,isbn_no,' . $bookId,
                'different:book_number',
            ];
        }
        return $rules;
    }
    public function attributes()
    {
        return [
            'book_category_id' => 'book category'
        ];
    }
}
