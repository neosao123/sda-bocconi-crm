<?php

namespace App\Http\Requests\Admin\Inventory;

use Illuminate\Foundation\Http\FormRequest;

class SmItemIssueRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $rules = [
            'role_id' => "required",
            'issue_date' => "required|date",
            'due_date' => "required|date|after_or_equal:issue_date",
            'item_category_id' =>  "required",
            'item_id' => "required",
            'quantity' => "required|gt:0",
            'description' => "sometimes|nullable"
        ];

        if ($this->input('role_id') == 2) {

            $rules['class'] = "required";
            $rules['section'] = "required";
            $rules['student'] = "required";
        }

        if ($this->input('role_id') == 3) {

            $rules['p_class'] = "required";
            $rules['p_section'] = "required";
            $rules['parent'] = "required";
        }

        return $rules;
    }

    public function attributes()
    {
        return [
            'role_id' => 'role',
            'item_category_id' => 'item category',
            'item_id' => 'item',
            'p_class' => 'class',
            'p_section' => 'section',
        ];
    }

    public function messages()
    {
        return [
            'item_id.required' => 'Item name is required.'
        ];
    }
}
