<?php

namespace App\Http\Requests\Admin\Academics;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SmClassRoomRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array
   */
  public function rules()
  {
    return [
      'room_no' => ['required', 'regex:/^[a-zA-Z0-9\-]+$/', 'max:20', Rule::unique('sm_class_rooms', 'room_no')->where('academic_id', getAcademicId())->where('school_id', auth()->user()->school_id)->ignore($this->id)],
      'capacity' => 'required|integer|gte:0'
    ];
  }

  public function messages()
  {
    return [
      'room_no.required' => 'The room number is required.',
      'room_no.regex' => 'The room number can only contain letters, numbers, and dashes.',
      'room_no.max' => 'The room number must not exceed 20 characters.',
      'room_no.unique' => 'The room number has already been taken for the selected academic year and school.',
      'capacity.required' => 'The capacity is required.',
      'capacity.integer' => 'The capacity must be an integer.',
      'capacity.gte' => 'The capacity must be greater than or equal to 0.',
    ];
  }
}
