<?php

namespace App\Http\Requests\Admin\Leave;

use Illuminate\Foundation\Http\FormRequest;

class SmLeaveDefineRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        return [
            'member_type' => "required",
            'leave_type' => 'required',
            'days' => 'required|integer|between:0,100',
            'class' => 'required_if:member_type,2',
            'section' => 'required_if:member_type,2',
            'student' => 'required_if:member_type,2',
            'staff' => 'required_unless:member_type,2',
        ];
    }
    public function messages()
    {
        return [
            'member_type.required' => 'The member type field is required.',
            'leave_type.required' => 'The leave type field is required.',
            'days.required' => 'The days field is required.',
            'days.integer' => 'The days field must be an integer.',
            'days.between' => 'The days field must be between 0 and 100.',
            'class.required_if' => 'The class field is required when role is student.',
            'section.required_if' => 'The section field is required when role is student.',
            'student.required_if' => 'The student field is required when role is student.',
            'staff.required_if' => 'The staff field is required.',
        ];
    }
}
