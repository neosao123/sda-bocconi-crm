<?php

namespace App\Http\Requests\Admin\GeneralSettings;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SmAcademicYearRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'year' => [
                'required',
                'numeric',
                'digits:4',
                Rule::unique('sm_academic_years')->ignore($this->id),
            ],
            'copy_with_academic_year' => 'sometimes|nullable|array',
            'starting_date' => 'required|date',
            'ending_date' => 'required|date|after_or_equal:starting_date',
            'title' => "required|max:150",
        ];
    }
}
