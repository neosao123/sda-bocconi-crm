<?php

namespace App\Http\Requests\Admin\Examination;

use Illuminate\Foundation\Http\FormRequest;

class AddMarkRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $rules = [];


        $rules += [
            'exam' => 'required',
            'class' => 'required',
            'section' => 'nullable',
            'subject' => 'required'
        ];

        return $rules;
    }
}
