<?php

namespace App\Http\Requests\Admin\GeneralSettings;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SmBaseSetupRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        return [
            'name' => [
                'required',
                'max:100',
                Rule::unique('sm_base_setups', 'base_setup_name')
                    ->where('base_group_id', $this->base_group)
                    ->ignore($this->id)
            ],
            'base_group' => 'required',
        ];
    }
}
