<?php

namespace App\Http\Requests\Admin\StudentInfo;

use App\GlobalVariable;
use App\User;
use App\SmStudent;
use App\Traits\CustomFields;
use App\Models\StudentRecord;
use Illuminate\Validation\Rule;
use App\Models\SmStudentRegistrationField;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Query\Builder;

class SmStudentAdmissionRequest extends FormRequest
{
  /**
   * Determine if the user is authorized to make this request.
   *
   * @return bool
   */
  use CustomFields;
  public function authorize()
  {
    return true;
  }

  /**
   * Get the validation rules that apply to the request.
   *
   * @return array
   */
  public function rules(Request $request)
  {

    $maxFileSize = generalSetting()->file_size * 1024;
    $student = null;
    $class_ids = [$this->class];
    $section_ids = [$this->section];

    $school_id = auth()->user()->school_id;

    if ($this->id) {
      $student = SmStudent::with('parents', 'studentRecords')->findOrFail($this->id);
      $class_ids = $student->studentRecords->pluck('class_id')->toArray();
      $section_ids = $student->studentRecords->pluck('section_id')->toArray();
      $academic_id = getAcademicId();
    } else {
      $academic_id = $this->academic_year ?? getAcademicId();
    }

    // print_r('Year ' . $academic_id);
    // echo 'Class';
    // print_r($class_ids);
    // echo 'Section';
    // print_r($section_ids);
    // die;

    $field = SmStudentRegistrationField::where('school_id', $school_id)
      ->when(in_array(auth()->user()->role_id, [10, 2]), function ($query) {
        $query->where('student_edit', 1)->where('is_required', 1);
      })
      ->when(auth()->user()->role_id == 3, function ($query) {
        $query->where('parent_edit', 1)->where('is_required', 1);
      })
      ->when(!in_array(auth()->user()->role_id, [2, 3, GlobalVariable::isAlumni()]), function ($query) {
        $query->where('is_required', 1);
      })
      ->pluck('field_name')
      ->toArray();
    $user_role_id = null;
    if ($this->filled('phone_number') || $this->filled('email_address')) {
      $user = User::when($this->filled('phone_number') && !$this->email_address, function ($q) {
        $q->where('phone_number', $this->phone_number)->orWhere('username', $this->phone_number);
      })
        ->when($this->filled('email_address') && !$this->phone_number, function ($q) {
          $q->where('email', $this->email_address)->orWhere('username', $this->email_address);
        })
        ->when($this->filled('email_address') && $this->filled('phone_number'), function ($q) {
          $q->where('phone_number', $this->phone_number);
        })
        ->first();
      if ($user) {
        $user_role_id = ($user->role_id == 2 || $user->role_id == GlobalVariable::isAlumni()) ? $user->role_id : null;
      }
    }

    $rules = [
      'admission_number' => [
        'numeric',
        'gt:0',
        Rule::unique('sm_students', 'admission_no')->ignore(optional($student)->id)->where('school_id', $school_id),
        Rule::requiredIf(function () use ($field) {
          return in_array('admission_number', $field);
        })
      ],
      'first_name' => [
        'required',
        'string',
        'regex:/^[a-zA-Z\s]+$/',
        'max:100',
        Rule::requiredIf(function () use ($field) {
          return in_array('first_name', $field);
        })
      ],
      'last_name' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('last_name', $field);
        }),
        'max:100',
        'string',
        'regex:/^[a-zA-Z\s]+$/',
      ],
      'gender' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('gender', $field);
        })
      ],
      'date_of_birth' => [
        'before:' . date('Y-m-d'),
        'after:1900-01-01',
        Rule::requiredIf(function () use ($field) {
          return in_array('date_of_birth', $field);
        })
      ],
      'blood_group' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('blood_group', $field);
        }),
        'nullable',
        'numeric'
      ],
      'religion' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('religion', $field);
        }),
        'nullable',
        'numeric'
      ],
      'caste' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('caste', $field);
        })
      ],

      'admission_date' => [
        'before:tomorrow',
        Rule::requiredIf(function () use ($field) {
          return in_array('admission_date', $field);
        }),
        'date'
      ],
      'student_category_id' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('student_category_id', $field);
        }),
        'nullable',
        'integer'
      ],
      'student_group_id' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('student_group_id', $field);
        }),
        'nullable',
        'integer'
      ],
      'height' => [
        'numeric',
        'gt:0',
        'regex:/^\d+(\.\d{1,2})?$/',
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return in_array('height', $field);
        })
      ],
      'weight' => [
        'numeric',
        'gt:0',
        'regex:/^\d+(\.\d{1,2})?$/',
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return in_array('weight', $field);
        })
      ],

      'fathers_name' => [
        'nullable',
        'max:100',
        'string',
        'regex:/^[a-zA-Z\s]+$/',
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('fathers_name', $field);
        }),
      ],
      'fathers_occupation' => [
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('fathers_occupation', $field);
        }),
        'max:100'
      ],

      'mothers_name' => [
        'nullable',
        'max:100',
        'string',
        'regex:/^[a-zA-Z\s]+$/',
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('mothers_name', $field);
        }),
      ],
      'mothers_occupation' => [
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('mothers_occupation', $field);
        }),
        'max:100'
      ],

      'guardians_name' => [
        'nullable',
        'max:100',
        'string',
        'regex:/^[a-zA-Z\s]+$/',
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('guardians_name', $field);
        }),
        'max:100'
      ],
      'relation' => [
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('relation', $field);
        })
      ],
      'guardians_occupation' => [
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('guardians_occupation', $field);
        }),
        'max:100'
      ],
      'guardians_address' => [
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return !$this->parent_id && !$this->staff_parent && in_array('guardians_address', $field);
        }),
        'max:200'
      ],

      'current_address' => [
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return in_array('current_address', $field);
        }),
        'max:200'
      ],
      'permanent_address' => [
        'nullable',
        Rule::requiredIf(function () use ($field) {
          return in_array('permanent_address', $field);
        }),
        'max:200'
      ],
      'route' => [
        Rule::requiredIf(function () use ($field) {
          return in_array('route', $field);
        }),
        'nullable',
        'integer'
      ],
      'vehicle' => [Rule::requiredIf(function () use ($field) {
        return in_array('vehicle', $field);
      }), 'nullable', 'integer'],
      'dormitory_name' => [Rule::requiredIf(function () use ($field) {
        return in_array('dormitory_name', $field);
      }), 'nullable', 'integer'],
      'room_number' => [Rule::requiredIf(function () use ($field) {
        return in_array('room_number', $field);
      }), 'nullable', 'integer'],
      'national_id_number' => [Rule::requiredIf(function () use ($field) {
        return in_array('national_id_number', $field);
      })],
      'local_id_number' => [Rule::requiredIf(function () use ($field) {
        return in_array('local_id_number', $field);
      })],
      'bank_account_number' => [
        'nullable',
        'numeric',
        'regex:/^\d{9,18}$/',
        Rule::requiredIf(function () use ($field) {
          return in_array('bank_account_number', $field);
        })
      ],
      'bank_name' => [
        'nullable',
        'string',
        'regex:/^[a-zA-Z\s]+$/',
        Rule::requiredIf(function () use ($field) {
          return in_array('bank_name', $field);
        })
      ],
      'previous_school_details' => [Rule::requiredIf(function () use ($field) {
        return in_array('previous_school_details', $field);
      })],
      'additional_notes' => [Rule::requiredIf(function () use ($field) {
        return in_array('additional_notes', $field);
      })],
      'ifsc_code' => [
        'nullable',
        'regex:/^[A-Z]{4}0[A-Z0-9]{6}$/',
        Rule::requiredIf(function () use ($field) {
          return in_array('ifsc_code', $field);
        })
      ],
      'document_file_1' => [
        'mimes:png,jpeg,jpg,pdf',
        Rule::requiredIf(function () use ($field) {
          return in_array('document_file_1', $field);
        }),
        'nullable',
        'max:' . $maxFileSize,
      ],
      'document_file_2' => [
        'mimes:png,jpeg,jpg,pdf',
        Rule::requiredIf(function () use ($field) {
          return in_array('document_file_2', $field);
        }),
        'nullable',
        'max:' . $maxFileSize,
      ],
      'document_file_3' => [
        'mimes:png,jpeg,jpg,pdf',
        Rule::requiredIf(function () use ($field) {
          return in_array('document_file_3', $field);
        }),
        'nullable',
        'max:' . $maxFileSize,
      ],
      'document_file_4' => [
        'mimes:png,jpeg,jpg,pdf',
        Rule::requiredIf(function () use ($field) {
          return in_array('document_file_4', $field);
        }),
        'nullable',
        'max:' . $maxFileSize,
      ],
    ];

    $rules += [
      'academic_year' =>  [
        'sometimes',
        Rule::requiredIf(function () use ($field) {
          return in_array('session', $field);
        })
      ],
      'class' => [
        Rule::requiredIf(function () {
          return $this->has('class');
        }),
      ],
      'section' => [
        Rule::requiredIf(function () {
          return $this->has('section');
        }),
      ],
    ];


    // dd($user_role_id);
    if ($user_role_id != 2 || $user_role_id != 10) {
      $rules += [
        'email_address' => [
          'required',
          'email',
          'regex:/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/',
          'different:guardians_email',
          Rule::requiredIf(function () use ($field) {
            return in_array('email_address', $field);
          }),
          Rule::unique('users', 'email')->ignore(optional($student)->user_id)
        ],
        'phone_number' => [
          'required',
          'numeric',
          'digits:10',
          Rule::requiredIf(function () use ($field) {
            return in_array('phone_number', $field);
          }),
          //   Rule::unique('users', 'phone_number')->where(function ($query) use ($student) {
          //     return  $query->whereNotNull('phone_number')->where('id', '!=', (optional($student)->user_id));
          //   })
        ],
        'guardians_email' => [
          'required',
          'email',
          'regex:/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/',
          'different:email_address',
          Rule::requiredIf(function () use ($field) {
            return !$this->parent_id && !$this->staff_parent && in_array('guardians_email', $field);
          })
        ],
        'guardians_phone' => [
          'required',
          'numeric',
          'digits:10',
          Rule::requiredIf(function () use ($field) {
            return !$this->parent_id && !$this->staff_parent && in_array('guardians_phone', $field);
          })
        ],

      ];
    }

    $path = $this->path();
    if ($path == "student-update") {
      $rules += [
        'roll_number' => [
          'required',
          'numeric',
          'gt:0',
        ],
      ];
    } else {
      $rules += [
        'roll_number' => [
          'required',
          'numeric',
          'gt:0',
          Rule::unique('student_records', 'roll_no')
            ->where(function (Builder $query) use ($school_id, $academic_id, $class_ids, $section_ids) {
              return $query->where('school_id', $school_id)
                ->where('academic_id', $academic_id)
                ->whereIn('class_id', $class_ids)
                ->whereIn('section_id', $section_ids);
            }),
        ],
      ];
    }

    if (is_show('custom_field') && isMenuAllowToShow('custom_field')) {
      $rules += $this->generateValidateRules("student_registration");
    }

    if ($request->hasFile('photo')) {
      $rules += [
        'photo' => [
          'mimes:png,jpeg,jpg',
          Rule::requiredIf(function () use ($field) {
            return in_array('photo', $field);
          })
        ],
      ];
    }

    if ($request->hasFile('mothers_photo')) {
      $rules += [
        'mothers_photo' => [
          'mimes:png,jpeg,jpg',
          Rule::requiredIf(function () use ($field) {
            return !$this->parent_id && !$this->staff_parent && in_array('mothers_photo', $field);
          })
        ],
      ];
    }

    if ($request->hasFile('fathers_photo')) {
      $rules += [
        'fathers_photo' => [
          'mimes:png,jpeg,jpg',
          Rule::requiredIf(function () use ($field) {
            return !$this->parent_id && !$this->staff_parent && in_array('fathers_photo', $field);
          })
        ],
      ];
    }

    if ($request->hasFile('guardians_photo')) {
      $rules += [
        'guardians_photo' => [
          'mimes:png,jpeg,jpg',
          Rule::requiredIf(function () use ($field) {
            return !$this->parent_id && !$this->staff_parent && in_array('guardians_photo', $field);
          })
        ],
      ];
    }

    return $rules;
  }
  public function attributes()
  {
    $attributes =  [
      'session' => 'Academic',
    ];
    return $attributes;
  }
}
