<?php

namespace App\Http\Requests\Admin\Dormitory;

use Illuminate\Foundation\Http\FormRequest;

class SmDormitoryRoomRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|max:100|regex:/^[a-zA-Z0-9]+$/',
            'dormitory' => "required",
            'room_type' => "required",
            'number_of_bed' => "required|numeric|max:99|gt:0",
            'cost_per_bed' => "required|numeric|max:99999999999|gte:0",
            'description' => 'sometimes|nullable|max:200'
        ];
    }
    public function messages()
    {
        return [
            'name.required' => 'The room number field is required.',
            'name.regex' => 'The room number field must be alphabetic & numeric characters.',
            'name.max' => 'The room number field cannot be greater than 100 characters.',
        ];
    }
}
