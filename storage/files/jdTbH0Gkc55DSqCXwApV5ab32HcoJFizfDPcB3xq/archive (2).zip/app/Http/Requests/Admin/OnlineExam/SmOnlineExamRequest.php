<?php

namespace App\Http\Requests\Admin\OnlineExam;

use Illuminate\Foundation\Http\FormRequest;
use App\Rules\TimeAfter;

class SmOnlineExamRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $rules = [
            'title' => 'required',
            'class' => 'required',
            'section' => 'required|array',
            'subject' => 'required',
            'date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:date',
            'start_time' => 'required',
            'end_time' => ['required', new TimeAfter(request()->input('start_time'))],
            'percentage' => 'required|numeric|min:0|max:100|regex:/^\d{1,3}(\.\d{1,2})?$/',
            'instruction' => 'required'
        ];
        if ($this->id) {
            $rules['section'] = 'required';
        }



        return $rules;
    }
    public function messages()
    {
        return [
            'percentage.required' => 'The percentage field is required.',
            'percentage.numeric' => 'The percentage must be a valid number.',
            'percentage.min' => 'The percentage must be greater than equals to 0.',
            'percentage.max' => 'The percentage must not exceed 100.',
            'percentage.regex' => 'The percentage must be a number between 0 and 100, with up to 2 decimal places.',
        ];
    }
}
