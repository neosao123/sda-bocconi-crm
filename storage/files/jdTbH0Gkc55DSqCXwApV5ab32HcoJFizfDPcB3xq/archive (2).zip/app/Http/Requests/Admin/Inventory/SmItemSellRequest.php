<?php

namespace App\Http\Requests\Admin\Inventory;

use Illuminate\Foundation\Http\FormRequest;

class SmItemSellRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //dd($this->all());
        return [
            'bank_id' => "required_if:payment_method,Bank",
            'income_head_id' => "required",
            'payment_method' => "required",
            'role_id' => "required",
            'reference_no' => "sometimes|nullable",
            'sell_date' => "required|date",
            'description' => "sometimes|nullable",
            // Items
            'items.*.item_id' => "required",
            'items.*.unit_price' => "required|gt:0",
            'items.*.quantity' => "required|gt:0",
            'items.*.total' => "sometimes|gt:0",
            'subTotalQuantity' => "sometimes|nullable",
            'subTotal' => "numeric|min:0",
            'totalPaid' =>  "numeric|min:0",
        ];
    }

    public function messages()
    {
        return [
            'role_id.required' => 'Sell to field is required.',
            // Items
            'items.*.item_id.required' => 'Please select item',
            'items.*.unit_price.required' => 'Please provide sell price',
            'items.*.unit_price.gt' => 'Item price must be greater than 0',
            'items.*.quantity.required' => 'Please provide unit quantity',
            'items.*.quantity.gt' => 'Unit quantity must be greater than 0',
            'items.*.total.gt' => 'Sub Total must be greater than 0',
        ];
    }
}
