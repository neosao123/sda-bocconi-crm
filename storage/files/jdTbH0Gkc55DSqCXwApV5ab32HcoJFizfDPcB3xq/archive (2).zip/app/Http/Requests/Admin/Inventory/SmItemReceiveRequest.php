<?php

namespace App\Http\Requests\Admin\Inventory;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

class SmItemReceiveRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'bank_id' => "required_if:payment_method,Bank",
            'expense_head_id' => "required",
            'supplier_id' => "required",
            'store_id' => "required",
            'reference_no' => "sometimes|nullable",
            'receive_date' => "required|date",
            'payment_method' => "required",
            'description' => "sometimes|nullable",
            //items
            'items.*.item_id' => "required",
            'items.*.unit_price' => "required|gt:0",
            'items.*.quantity' => "required|gt:0",
            'items.*.total' => "sometimes|gt:0",
            'subTotalQuantity' => "sometimes|nullable",
            'subTotal' => "numeric|min:0",
            'totalPaid' =>  "numeric|min:0",
        ];
    }

    public function messages(): array
    {
        return [
            //items
            'items.*.item_id.required' => 'Please select item',
            'items.*.unit_price.required' => 'Please provide unit price',
            'items.*.unit_price.gt' => 'Item price must be greater than 0',
            'items.*.quantity.required' => 'Please provide unit quantity',
            'items.*.quantity.gt' => 'Unit quantity must be greater than 0',
            'items.*.total.gt' => 'Sub Total must be greater than 0',
        ];
    }
}
