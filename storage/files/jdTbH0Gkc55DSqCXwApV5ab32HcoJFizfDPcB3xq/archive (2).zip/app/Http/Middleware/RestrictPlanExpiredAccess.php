<?php

namespace App\Http\Middleware;

use App\Models\SuperAdmin\SchoolAccount;
use Closure;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RestrictPlanExpiredAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $tenant_id = tenant('id') ?? "";
        if ($tenant_id != "") {
            $school = DB::connection("central")->table("school_accounts")->where('tenant_id', $tenant_id)->where([
                'is_email_verified'  => 1,
                'active_status' => 1,
                'is_enabled' => 'yes',
            ])->first();

            if ($school && $school->is_expired == 1) {
                return $next($request);
            }
        }
        return redirect('/');
    }
}
