<?php

namespace App\Http\Middleware;

use Closure;
use Stancl\Tenancy\Middleware\InitializeTenancyBySubdomain;
use Symfony\Component\HttpFoundation\Response;


class IdentifyTenantBySubdomain extends InitializeTenancyBySubdomain
{
    public function handle($request, Closure $next)
    {
        // Handle central domain (optional, if applicable)
        if (in_array($request->getHost(), config('tenancy.central_domains'))) {
            return $next($request);
        }

        return parent::handle($request, $next);
    }
}
