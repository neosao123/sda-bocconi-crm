<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
  /**
   * The URIs that should be excluded from CSRF verification.
   *
   * @var array<int, string>
   */
  protected $except = [
    'day-wise-class-routine',
    'all-issued-book-ajax',
    'leave-define-ajax',
    'delete-exam-routine',
    'item-list-ajax',
    'get-receive-item',
    'item-receive-list-ajax',
    'check-product-quantity',
    'bank-account-datatable',
    'student/field/show',
    'student/field/switch',
    'teacher/field_view',
    'staff/field/switch',
    'online-exam-question-assign',
    "weekend/switch",
    'delete-payroll-payment'
  ];
}
