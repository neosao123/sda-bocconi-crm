<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckSuperadminAuthMiddleware
{
  public function handle(Request $request, Closure $next)
  {
    // Get central domains from config
    $centralDomain = config('tenancy.central_domains')[1];
    // Check if the request host is in central domains
    $currentHost = $request->getHost();
    if ($centralDomain === $currentHost) {
      if (Auth::guard('superadmin')->check()) {
        return $next($request);
      } else {
        return redirect('/session-out');
      }
    }
    return $next($request);
  }
}
