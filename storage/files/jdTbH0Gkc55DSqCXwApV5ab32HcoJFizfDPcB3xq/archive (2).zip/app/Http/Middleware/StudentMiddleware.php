<?php

namespace App\Http\Middleware;

use App\GlobalVariable;

use Closure;
use App\User;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;

class StudentMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Auth::user() && Auth::user()->role_id == 2) {
            return $next($request);
        } else {
            Auth::logout();
            return redirect('/');
        }
    }
}
