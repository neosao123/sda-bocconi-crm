<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Route;
use Modules\RolePermission\Entities\InfixRole;
use Modules\RolePermission\Entities\Permission;
use Modules\RolePermission\Entities\InfixModuleInfo;
use Modules\RolePermission\Entities\InfixPermissionAssign;
use Modules\RolePermission\Entities\InfixModuleStudentParentInfo;

class UserRolePermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $route = null)
    {
        if (!Auth::check()) {
            return redirect('/');
        }
        $roleId = Auth::user()->role_id;
        if ($roleId == 1) {
            return $next($request);
        } else {
            $role = InfixRole::with('assignedPermission')->where('id', $roleId)->first();
            $already_assigned = $role->assignedPermission->pluck('permission_id')->toArray();
            $get_permission = Permission::with(['subModule'])->where('route', $route)->first();

            if ($get_permission) {
                if (in_array($get_permission->id, $already_assigned)) {
                    return $next($request);
                } else {
                    abort(403);
                }
            }
            return $next($request);
        }
    }
}
