<?php

namespace App\Http\Controllers;

use App\SmGeneralSettings;
use App\SmNoticeBoard;
use App\SmStaff;
use App\SmStudent;
use App\SmHoliday;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\DueFeesLoginPrevent;

class DashboardController extends Controller
{
  public function index()
  {
    try {
      $user = Auth::user();
      $role_id = $user->role_id;
      $is_due_fees_login_permission   = SmGeneralSettings::where('school_id', Auth::user()->school_id)->first('due_fees_login');
      $is_due_fees_login_permission   = $is_due_fees_login_permission->due_fees_login;
      $student_due_fees_login_prevent = DueFeesLoginPrevent::where('user_id', $user->id)->where('school_id', $user->school_id)->where('role_id', 2)->first();
      $parent_due_fees_login_prevent  = DueFeesLoginPrevent::where('user_id', $user->id)->where('school_id', $user->school_id)->where('role_id', 3)->first();

      $notices = SmNoticeBoard::query();
      $notices->where('active_status', 1)->where('academic_id', getAcademicId())->where('school_id', $user->school_id);
      $notices->when(auth()->user()->role_id != 1, function ($query) {
        $query->where('inform_to', 'LIKE', '%' . auth()->user()->role_id . '%');
      });
      $notices = $notices->get();

      $school_id = $user->school_id;

      $staffs = SmStaff::where('school_id', $school_id)->where('active_status', 1);
      $all_staffs = $staffs->where('role_id', '!=', 1)->where('school_id', $school_id)->get();
      $all_students = SmStudent::where('active_status', 1)->where('school_id', $school_id)->get();
      $totalStudents = $all_students->count();
      $totalParents = $all_students->whereNotNull('parent_id')->unique('parent_id')->count();
      $totalTeachers = $all_staffs->where('role_id', 4)->count();
      $totalStaffs = $all_staffs->count();
      if (($user->role_id == 1) && ($user->is_administrator == "yes")) {   #SuperAdmin
        $data = [
          'notices' => $notices, 'totalStudents' => $totalStudents, 'totalParents' => $totalParents, 'totalTeachers' => $totalTeachers, 'totalStaffs' => $totalStaffs
        ];
        return view('school.backEnd.dashboard', $data);
      } else if ($role_id == 2) {    #Student
        return redirect('student-dashboard');
      } else if ($role_id == 3) {  #Parent
        return redirect('parent-dashboard');
      } else {
        $data = [
          'notices' => $notices, 'totalStudents' => $totalStudents, 'totalParents' => $totalParents, 'totalTeachers' => $totalTeachers, 'totalStaffs' => $totalStaffs
        ];
        return view('school.backEnd.dashboard', $data);
      }
    } catch (\Exception $e) {
      $this->toastr->error('Operation Failed,' . $e->getMessage(), 'Failed');
      return redirect()->back();
    }
  }

  public function viewNotice($id)
  {
    try {
      $notice = SmNoticeBoard::find($id);
      return view('school.backEnd.dashboard.view_notice', compact('notice'));
    } catch (\Exception $e) {
      Toastr::error('Operation Failed', 'Failed');
      return redirect()->back();
    }
  }
}
