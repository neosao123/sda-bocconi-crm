<?php

namespace App\Http\Controllers\Admin\Academics;

use App\SmSubject;
use App\tableList;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use App\Http\Requests\Admin\Academics\SmSubjectRequest;
use App\Http\Requests\Admin\Academics\SmSubjectStoreRequest;

class SmSubjectController extends Controller
{
  public function index(Request $request)
  {
    try {
      $subjects = SmSubject::orderBy('id', 'DESC')->get();
      return view('school.backEnd.academics.subject', compact('subjects'));
    } catch (\Exception $e) {
      Toastr::error('Operation Failed', 'Failed');
      return redirect()->back();
    }
  }

  public function store(SmSubjectRequest $request)
  {
    try {

      if ($request->subject_type == "T") { # check for theory
        $subject = new SmSubject();
        $subject->subject_name = $request->subject_name;
        $subject->subject_code = $request->subject_code;
        if (@generalSetting()->result_type == 'mark') {
          $subject->pass_mark = $request->pass_mark;
        }
        $subject->created_by   = auth()->user()->id;
        $subject->school_id    = auth()->user()->school_id;
        $subject->academic_id  = getAcademicId();
        $subject->subject_type = 'T';
        $subject->save();
      } else if ($request->subject_type == "P") { # check for practical
        $subject = new SmSubject();
        $subject->subject_name = $request->subject_name;
        $subject->subject_code = $request->subject_code;
        if (@generalSetting()->result_type == 'mark') {
          $subject->pass_mark = $request->pass_mark;
        }
        $subject->created_by   = auth()->user()->id;
        $subject->school_id    = auth()->user()->school_id;
        $subject->academic_id  = getAcademicId();
        $subject->subject_type = 'P';
        $subject->save();
      } else { # check for theory & practical
        // Theory
        $subject = new SmSubject();
        $subject->subject_name = $request->subject_name . ' (Theory)';
        $subject->subject_code = $request->subject_code . '-T';
        if (@generalSetting()->result_type == 'mark') {
          $subject->pass_mark = $request->pass_mark;
        }
        $subject->created_by   = auth()->user()->id;
        $subject->school_id    = auth()->user()->school_id;
        $subject->academic_id  = getAcademicId();
        $subject->subject_type = 'T';
        $subject->save();
        // Practical
        $subject = new SmSubject();
        $subject->subject_name = $request->subject_name . " (Practical)";
        $subject->subject_code = $request->subject_code . '-P';
        if (@generalSetting()->result_type == 'mark') {
          $subject->pass_mark = $request->pass_mark;
        }
        $subject->created_by   = auth()->user()->id;
        $subject->school_id    = auth()->user()->school_id;
        $subject->academic_id  = getAcademicId();
        $subject->subject_type = 'P';
        $subject->save();
      }

      Toastr::success('Operation successful', 'Success');
      return redirect()->back();
    } catch (\Exception $e) {
      Toastr::error('Operation Failed ' . $e->getMessage(), 'Failed');
      return redirect()->back();
    }
  }

  public function edit(Request $request, $id)
  {
    try {
      $subject = SmSubject::find($id);
      $subjects = SmSubject::orderBy('id', 'DESC')->get();
      return view('school.backEnd.academics.subject', compact('subject', 'subjects'));
    } catch (\Exception $e) {
      Toastr::error('Operation Failed', 'Failed');
      return redirect()->back();
    }
  }

  public function update(SmSubjectRequest $request)
  {
    try {
      $subject = SmSubject::find($request->id);
      $subject->subject_name = $request->subject_name;
      $subject->subject_type = $request->subject_type;
      $subject->subject_code = $request->subject_code;
      if (@generalSetting()->result_type == 'mark') {
        $subject->pass_mark = $request->pass_mark;
      }
      $subject->save();

      Toastr::success('Operation successful', 'Success');
      return redirect('subject');
    } catch (\Exception $e) {
      Toastr::error('Operation Failed', 'Failed');
      return redirect()->back();
    }
  }

  public function delete(Request $request, $id)
  {
    try {
      $tables = tableList::getTableList('subject_id', $id);
      try {
        if ($tables == null) {
          // $delete_query = $section = SmSubject::destroy($id);
          SmSubject::destroy($id);
          Toastr::success('Operation successful', 'Success');
          return redirect('subject');
        } else {
          $msg = 'This data already used in  : ' . $tables . ' Please remove those data first';
          Toastr::error($msg, 'Failed');
          return redirect()->back();
        }
      } catch (\Illuminate\Database\QueryException $e) {
        $msg = 'This data already used in  : ' . $tables . ' Please remove those data first';
        Toastr::error($msg, 'Failed');
        return redirect()->back();
      }
    } catch (\Exception $e) {
      Toastr::error('Operation Failed', 'Failed');
      return redirect()->back();
    }
  }
}
