<?php

namespace App\Http\Controllers\Admin\StudentInfo;

use App\SmClass;
use App\SmParent;
use App\SmStudent;
use App\SmAcademicYear;
use App\SmClassTeacher;
use App\Traits\CustomFields;
use Illuminate\Http\Request;
use App\StudentRecord;
use App\Traits\NotificationSend;
use App\Traits\DatabaseTableTrait;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;
use App\Traits\DirectFeesAssignTrait;
use App\Models\StudentRecordTemporary;
use App\SmLibraryMember;
use App\User;
use Illuminate\Support\Facades\Schema;

class StudentMultiRecordController extends Controller
{
    use NotificationSend;
    use DatabaseTableTrait;
    use DirectFeesAssignTrait;

    public function multiRecord(Request $request)
    {
        $students  = null;
        $data = [];

        if (!empty($request->all())) {
            $record_student_ids  = StudentRecord::when($request->class_id, function ($q) use ($request) {
                $q->where('class_id', $request->class_id);
            })->when($request->section_id, function ($q) use ($request) {
                $q->where('section_id', $request->section_id);
            })->when($request->academic_year, function ($q) use ($request) {
                $q->where('session_id', $request->academic_year);
            }, function ($q) {
                $q->where('session_id', getAcademicId());
            })->when($request->student, function ($q) use ($request) {
                $q->where('student_id', $request->student);
            })->pluck('student_id')->toArray();


            $students = SmStudent::whereIn('id', $record_student_ids)->where('active_status', 1)->get();
        }
        $selected['student_id'] = $request->student;
        $selected['academic_year'] = $request->academic_year;
        $selected['class_id'] = $request->class_id;
        $selected['section_id'] = $request->section_id;

        $sessions = SmAcademicYear::where('school_id', auth()->user()->school_id)->get();
        $classes = SmClass::get();

        return view('school.backEnd.studentInformation.multi_class_student', compact('sessions', 'students', 'classes', 'data', 'selected'));
    }
    public function studentMultiRecord($student_id)
    {
        $classes = SmClass::get();
        $student = SmStudent::findOrFail($student_id);
        return view('school.backEnd.studentInformation.inc._multiple_class_record', compact('student', 'classes'));
    }
    public function multiRecordStore(Request $request)
    {
        // dd($request->all());
        // try {
        $class_list = [];
        $section_list = [];
        $default_id = $request->default ? (int)$request->default : null;
        if ($request->new_record) {
            foreach ($request->new_record as $row_id => $newRecord) {
                $is_default = ($row_id == $default_id) ? 1 : null;
                $class = isset($newRecord['class'][0]) ? $newRecord['class'][0] : null;
                $section = isset($newRecord['section'][0]) ? $newRecord['section'][0] : null;
                if (is_null($class) || is_null($section)) {
                    $status = false;
                    $message = __('student.Record info updated Failed');
                    return response()->json(['status' => $status, 'message' => $message]);
                }
                $roll_number = isset($newRecord['roll_number'][0]) ? $newRecord['roll_number'][0] : null;
                $request = $request->merge([
                    'class' => $class,
                    'section' => $section,
                    'roll_number' => $roll_number,
                    'is_default' => $is_default
                ]);
                $checkExit = $this->checkExitRecord($request);
                $checkExitRollNumber = $this->checkExitRollNumber($request);

                if ($class && $section && !$checkExit && !$checkExitRollNumber) {
                    $this->insertStudentRecord($request);
                }
            }
        }
        if ($request->old_record) {
            foreach ($request->old_record as $record_id => $oldRecord) {
                $is_default = $record_id == $default_id ? 1 : null;
                $class = isset($oldRecord['class'][0]) ? $oldRecord['class'][0] : null;
                $section = isset($oldRecord['section'][0]) ? $oldRecord['section'][0] : null;
                $roll_number = isset($oldRecord['roll_number'][0]) ? $oldRecord['roll_number'][0] : null;
                $request = $request->merge([
                    'class' => $class,
                    'section' => $section,
                    'record_id' => $record_id,
                    'roll_number' => $roll_number,
                    'is_default' => $is_default
                ]);

                $checkExit = $this->checkExitRecord($request);
                $checkExitRollNumber = $this->checkExitRollNumber($request);
                if ($class && $section && !$checkExit && !$checkExitRollNumber) {
                    $this->insertStudentRecord($request);
                }
            }
            if ($request->old_record) {
                foreach ($request->old_record as $record_id => $oldRecord) {
                    $is_default = ($record_id == $default_id) ? 1 : null;

                    $class = isset($oldRecord['class'][0]) ? $oldRecord['class'][0] : null;
                    $section = isset($oldRecord['section'][0]) ? $oldRecord['section'][0] : null;
                    $roll_number = isset($oldRecord['roll_number'][0]) ? $oldRecord['roll_number'][0] : null;
                    $request = $request->merge([
                        'class' => $class,
                        'section' => $section,
                        'record_id' => $record_id,
                        'roll_number' => $roll_number,
                        'is_default' => $is_default
                    ]);

                    $checkExit = $this->checkExitRecord($request);

                    $checkExitRollNumber = $this->checkExitRollNumber($request);
                    if ($class && $section && !$checkExit && !$checkExitRollNumber) {
                        $this->insertStudentRecord($request);
                    }
                    if ($checkExit) {
                        array_push($class_list, $checkExit->class->class_name);
                        array_push($section_list, $checkExit->section->section_name);
                    }
                }
            }
            $validation = '';
            if (!empty($class_list && $section_list)) {
                $validation = implode(',', $class_list) . ' & ' . implode(',', $section_list) . ' ' . __('student.Record already exit ,please Delete or restore');
            }
            $status = true;
            $message = __('student.Record info updated');
            return response()->json(['status' => $status, 'message' => $message, 'validation' => $validation]);
        }
        // } catch (\Throwable $th) {
        //     $status = false;
        //     $message = __('student.Record info updated Failed');
        //     return response()->json(['status' => $status, 'message' => $th->getMessage()]);
        // }
    }
    public function insertStudentRecord($request, $pre_record = null)
    {
        if ($request->is_default != null) {
            StudentRecord::where('academic_id', getAcademicId())
                ->where('student_id', $request->student_id)
                ->where('school_id', auth()->user()->school_id)->update([
                    'is_default' => 0,
                ]);
        }
        if (generalSetting()->multiple_roll == 0 && $request->roll_number) {

            StudentRecord::where('student_id', $request->student_id)
                ->where('school_id', auth()->user()->school_id)
                ->where('academic_id', getAcademicId())
                ->update([
                    'roll_no' => $request->roll_number,
                ]);
        }

        if ($request->record_id) {
            $studentRecord = StudentRecord::with('studentDetail')->find($request->record_id);
        } else {
            $studentRecord = new StudentRecord;
        }

        $studentRecord->student_id = $request->student_id;
        if ($request->roll_number) {
            $studentRecord->roll_no = $request->roll_number;
        }
        $studentRecord->is_promote = $request->is_promote ?? 0;
        if ($request->is_default != null) {
            $studentRecord->is_default = $request->is_default;
        }



        $studentRecord->class_id = $request->class;
        $studentRecord->section_id = $request->section;
        $studentRecord->session_id = $request->session ?? getAcademicId();

        $studentRecord->school_id = Auth::user()->school_id;
        $studentRecord->academic_id = $request->session ?? getAcademicId();
        $studentRecord->save();

        $class_teacher = SmClassTeacher::whereHas('teacherClass', function ($q) use ($request) {
            $q->where('active_status', 1)
                ->where('class_id', $request->class)
                ->where('section_id', $request->section);
        })
            ->where('academic_id', getAcademicId())
            ->where('school_id', auth()->user()->school_id)
            ->first();
        if ($class_teacher) {
            $data['class_id'] = $request->class;
            $data['section_id'] = $request->section;
            $data['teacher_name'] = $class_teacher->teacher->full_name;
        }
    }
    public function restoreStudentRecord(int $record_id)
    {
        //try {
        $record = StudentRecord::find($record_id);
        $student_detail = SmStudent::find($record->student_id);
        $siblings = SmStudent::where('parent_id', $student_detail->parent_id)->where('school_id', Auth::user()->school_id)->get();

        DB::beginTransaction();
        $student = SmStudent::find($record->student_id);
        $student->active_status = 1;
        $student->save();


        $student_user = User::find($student_detail->user_id);
        $student_user->active_status = 1;
        $student_user->save();



        $library_member = SmLibraryMember::where('student_staff_id', @$student_user->id)->first();

        if ($library_member != "") {

            $library_member->active_status = 1;
            $library_member->save();
        }


        if (count($siblings) == 1) {
            $parent = SmParent::find($student_detail->parent_id);
            $parent->active_status = 1;
            $parent->save();
        }

        $student_user = User::find($student_detail->user_id);
        $student_user->active_status = 1;
        $student_user->save();

        if (count($siblings) == 1) {

            $parent_user = User::find($student_detail->parents->user_id);
            $parent_user->active_status = 1;
            $parent_user->save();
        }

        DB::commit();
        if ($student_detail) {

            if ($student_detail) {
                Toastr::success('Operation successful', 'Success');
                return redirect()->back();
            } else {
                Toastr::error('Operation Failed', 'Failed');
                return redirect()->back();
            }
        } else {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
        // $this->deleteRecordCondition($record->student_id, $record->id, 'restore');
        // Toastr::success('Operation Successful', 'success');
        // return redirect()->back();
        /*} catch (\Throwable $th) {
            Toastr::error($th->getMessage());
            return redirect()->back();
        }*/
    }
    public function studentRecordDelete(Request $request)
    {

        try {
            $record_id = $request->record_id;
            $student_id = $request->student_id;

            if ($record_id && $student_id) {
                $this->deleteRecordCondition($student_id, $record_id, 'disable');
            }
            $status = true;
            $message = __('student.Record Remove Successfully');
            return response()->json(['status' => $status, 'message' => $message]);
            // Toastr::success($message, 'success');
            // return redirect()->back();
        } catch (\Throwable $th) {
            $status = false;
            $message = $th->getMessage();
            return response()->json(['status' => $status, 'message' => $message]);
            // Toastr::success($message, 'error');
            // return redirect()->back();
        }
    }
    public function studentRecordDeletePermanently(Request $request)
    {
        try {
            $record = StudentRecord::find($request->id);
            $this->deleteRecordCondition($record->student_id, $record->id, 'delete');
            $record->delete();
            Toastr::success('Operation Successful', 'success');
            return redirect()->back();
        } catch (\Throwable $th) {
            Toastr::error($th->getMessage());
            return redirect()->back();
        }
    }
    public function deleteRecordCondition(int $student_id, int $record_id, string $type = 'disable')
    {

        $tableWithRecordIdActiveStatus = $this->tableWithRecordIdActiveStatus();

        if ($type == 'delete') {
            foreach ($tableWithRecordIdActiveStatus as $table) {
                if ((Schema::hasColumn($table, 'record_id'))) {
                    $model = DB::table($table)->where('record_id', $record_id)->where('school_id', auth()->user()->school_id)->limit(1);
                }
                if ((Schema::hasColumn($table, 'student_record_id'))) {
                    $model = DB::table($table)->where('student_record_id', $record_id)->where('school_id', auth()->user()->school_id)->limit(1);
                }

                if ($model) {
                    // dump($model);
                    if ($type == 'delete') {

                        $model->Delete();
                    } else if ($type == 'disable') {
                        $model->update([
                            'active_status' => 0
                        ]);
                    } else if ($type == 'restore') {
                        $model->update([
                            'active_status' => 1
                        ]);
                    }
                }
            }
        }
        if ($type == 'disable') {

            $recordTemporary = StudentRecordTemporary::updateOrCreate([
                'sm_student_id' => $student_id,
                'student_record_id' => $record_id,
            ]);
            $recordTemporary->user_id = auth()->user()->id;
            $recordTemporary->school_id = auth()->user()->school_id;
            $recordTemporary->save();

            StudentRecord::where('student_id', $student_id)->where('id', $record_id)->update([
                'active_status' => 0
            ]);
        }

        if ($type == 'delete' || $type == 'restore') {

            $model = StudentRecordTemporary::where('sm_student_id', $student_id)->where('student_record_id', $record_id)->first();
            if ($model) {
                $model->delete();
            }
            if ($type == 'restore') {
                StudentRecord::where('student_id', $student_id)->where('id', $record_id)->update([
                    'active_status' => 1
                ]);
                // SmStudent::where('id', $student_id)->where('id', $record_id)->update([
                //     'active_status' => 1
                // ]);

            }
        }
    }
    public function deleteStudentRecord(Request $request)
    {
        $studentRecords = StudentRecord::with('studentDetail')
            ->whereHas('studentDetail', function ($query) {
                $query->where('active_status', 0);
            })
            ->where('school_id', auth()->user()->school_id)
            ->where('academic_id', getAcademicId())->get();
        return view("school.backEnd.studentInformation.back_up_student_record", compact('studentRecords'));
    }
    private function checkExitRecord(Request $request)
    {

        $exit = StudentRecord::where('class_id', $request->class)
            ->where('section_id', $request->section)
            ->where('student_id', $request->student_id)
            ->when($request->record_id, function ($q) use ($request) {
                $q->where('id', '!=', $request->record_id);
            })
            ->where('school_id', auth()->user()->school_id)
            ->first();

        if ($exit) {
            return $exit;
        }
        return false;
    }
    private function checkExitRollNumber(Request $request): bool
    {
        if (!$request->roll_number && generalSetting()->multiple_roll == 0) return false;

        $roll_number =  StudentRecord::where('class_id', $request->class)
            ->where('section_id', $request->section)
            ->when($request->roll_number, function ($q) use ($request) {
                $q->where('roll_no', $request->roll_number);
            })->where('school_id', auth()->user()->school_id)
            ->first();
        if ($roll_number) {
            return true;
        }
        return false;
    }
}
