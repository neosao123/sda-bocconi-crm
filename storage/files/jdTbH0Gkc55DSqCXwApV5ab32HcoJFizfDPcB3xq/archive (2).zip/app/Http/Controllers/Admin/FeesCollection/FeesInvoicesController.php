<?php

namespace App\Http\Controllers\Admin\FeesCollection;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\FeesInvoice;
use App\SmClass;
use App\SmStudent;
use App\SmAcademicYear;
use App\SmFeesType;
use Illuminate\Support\Facades\Auth;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;


class FeesInvoicesController extends Controller
{
    public function __construct()
    {
        $this->middleware('PM');
    }

    public function fees_invoices(Request $r)
    {
        try {
            $classes = SmClass::where('active_status', 1)
                ->where('academic_id', getAcademicId())
                ->where('school_id', Auth::user()->school_id)
                ->get();
            $students = SmStudent::where('academic_id', getAcademicId())
                ->where('school_id', Auth::user()->school_id)
                ->get();
            $sessions = SmAcademicYear::where('active_status', 1)
                ->where('school_id', Auth::user()->school_id)
                ->get();
            $fees_types = SmFeesType::get();
            $fees_invoices = FeesInvoice::with('feesType', 'academicYear', 'class', 'section', 'student')->where('fees_invoices.academic_year_id', getAcademicId())->get();
            return view('school.backEnd.feesCollection.fees_invoice', compact('fees_invoices', 'classes', 'sessions',  'fees_types', 'students'));
        } catch (\Exception $e) {
            dd($e->getMessage());
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    public function fees_invoices_store(Request $request)
    {

        $request->validate([
            'fees_types' => 'required',
            'academic_year' => 'required',
            'class_id' => 'required',
            'section_id' => 'required',
            'student' => 'required',
            'description' => 'nullable',
            'payment_mode' => 'nullable',
            'reference_no' => 'nullable',
            'invoice_date' => 'required|date|before:tomorrow',
            'fees_amount' => ['required', 'numeric', 'gt:0', 'regex:/^\d+(\.\d{1,2})?$/'],
        ], [
            'fees_types.required' => 'The fees type is required.',
            'academic_year.required' => 'The academic year is required.',
            'class_id.required' => 'The class is required.',
            'section_id.required' => 'The section is required.',
            'student.required' => 'The student is required.',
            'fees_amount.required' => 'The fees amount is required.',
            'fees_amount.numeric' => 'The fees amount must be a number.',
            'fees_amount.gt' => 'The fees amount must be greater than zero.',
            'fees_amount.regex' => 'The fees amount must be a valid decimal with up to two decimal places.',
            'invoice_date.required' => 'The invoice date is required.',
            'invoice_date.date' => 'The invoice date must be a valid date.',
            'invoice_date.before' => 'The invoice date must be a date before tomorrow.'
        ]);

        $fees_invoice = new FeesInvoice();
        $fees_invoice->fees_type_id = $request->fees_types;
        $fees_invoice->academic_year_id = $request->academic_year;
        $fees_invoice->class_id = $request->class_id;
        $fees_invoice->section_id = $request->section_id;
        $fees_invoice->student_id = $request->student;
        $fees_invoice->description = $request->description;
        $fees_invoice->payment_mode = $request->payment_mode;
        $fees_invoice->reference_no = $request->reference_no;
        $fees_invoice->invoice_date = Carbon::parse($request->invoice_date)->format('Y-m-d');
        $fees_invoice->amount = $request->fees_amount;
        $fees_invoice->save();

        DB::commit();
        Toastr::success('Operation successful', 'Success');
        return redirect()->back();
    }

    public function fess_invoices_edit($id = "")
    {
        if ($id != "") {
            $fees_invoice = FeesInvoice::find($id);
            $fees_invoices = FeesInvoice::with('feesType', 'academicYear', 'class', 'section', 'student')->get();
            $classes = SmClass::where('active_status', 1)
                ->where('academic_id', getAcademicId())
                ->where('school_id', Auth::user()->school_id)
                ->get();
            $students = SmStudent::where('academic_id', getAcademicId())
                ->where('school_id', Auth::user()->school_id)
                ->get();
            $sessions = SmAcademicYear::where('active_status', 1)
                ->where('school_id', Auth::user()->school_id)
                ->get();
            $fees_types = SmFeesType::get();
            $selected = [
                'academic_year' => $fees_invoice->academic_year_id,
                'class_id' => $fees_invoice->class_id,
                'section_id' => $fees_invoice->section_id,
                'student_id' => $fees_invoice->student_id
            ];

            return view('school.backEnd.feesCollection.fees_invoice', compact('selected', 'fees_invoice', 'fees_invoices', 'classes', 'sessions',  'fees_types', 'students'));
        } else {
            Toastr::success('Invalid Id', 'success');
            return redirect()->back();
        }
    }

    public function fees_invoices_update(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'fees_types' => 'required',
            'academic_year' => 'required',
            'class_id' => 'required',
            'section_id' => 'required',
            'student' => 'required',
            'description' => 'nullable',
            'payment_mode' => 'nullable',
            'reference_no' => 'nullable',
            'invoice_date' => 'required|date|before:tomorrow',
            'fees_amount' => ['required', 'numeric', 'gt:0', 'regex:/^\d+(\.\d{1,2})?$/'],
        ], [
            'fees_types.required' => 'The fees type is required.',
            'academic_year.required' => 'The academic year is required.',
            'class_id.required' => 'The class is required.',
            'section_id.required' => 'The section is required.',
            'student.required' => 'The student is required.',
            'description.required' => 'The description is required.',
            'fees_amount.required' => 'The fees amount is required.',
            'fees_amount.numeric' => 'The fees amount must be a number.',
            'fees_amount.gt' => 'The fees amount must be greater than zero.',
            'fees_amount.regex' => 'The fees amount must be a valid decimal with up to two decimal places.',
            'invoice_date.required' => 'The invoice date is required.',
            'invoice_date.date' => 'The invoice date must be a valid date.',
            'invoice_date.before' => 'The invoice date must be a date before tomorrow.'
        ]);

        $fees_invoice = FeesInvoice::findOrFail($request->id);
        $fees_invoice->fees_type_id = $request->fees_types;
        $fees_invoice->academic_year_id = $request->academic_year;
        $fees_invoice->class_id = $request->class_id;
        $fees_invoice->section_id = $request->section_id;
        $fees_invoice->student_id = $request->student;
        $fees_invoice->description = $request->description;
        $fees_invoice->payment_mode = $request->payment_mode;
        $fees_invoice->reference_no = $request->reference_no;
        $fees_invoice->invoice_date = Carbon::parse($request->invoice_date)->format('Y-m-d');
        $fees_invoice->amount = $request->fees_amount;
        $fees_invoice->save();

        DB::commit();
        Toastr::success('Operation successful', 'Success');
        return redirect('fees/fees-invoice');
    }

    public function fees_invoices_delete($id)
    {
        if ($id != "") {
            $fees_invoice = FeesInvoice::find($id);
            if ($fees_invoice) {
                $fees_invoice->delete();
                DB::commit();
                Toastr::success('Operation successful', 'Success');
                return redirect('fees/fees-invoice');
            } else {
                Toastr::error('Operation Failed', 'Failed');
                return redirect()->back();
            }
        } else {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    public function fees_invoices_print($id = "")
    {
        try {
            if ($id != "") {
                $fees_invoice = FeesInvoice::with('feesType', 'academicYear', 'class', 'section', 'student')->find($id);
                // $fees_invoices = FeesInvoice::with('feesType', 'academicYear', 'class', 'section', 'student')->get();
                // $classes = SmClass::where('active_status', 1)
                //     ->where('academic_id', getAcademicId())
                //     ->where('school_id', Auth::user()->school_id)
                //     ->get();
                // $students = SmStudent::where('academic_id', getAcademicId())
                //     ->where('school_id', Auth::user()->school_id)
                //     ->get();
                // $sessions = SmAcademicYear::where('active_status', 1)
                //     ->where('school_id', Auth::user()->school_id)
                //     ->get();
                // $fees_types = SmFeesType::get();
                // $selectedStudent = SmStudent::find($fees_invoice->student_id);
                // dd($selectedStudent);
                $print = request()->print;
                return view(
                    'school.backEnd.feesCollection.fees_invoice_print',
                    [
                        'fees_invoice' => $fees_invoice,
                        // 'fees_invoices' => $fees_invoices,
                        // 'classes' => $classes,
                        // 'academic_year' => $sessions,
                        // 'students' => $students,
                        // 'student' => $selectedStudent,
                        // 'fees_types' => $fees_types,
                        'print' => $print,
                    ]
                );

                $pdf = Pdf::loadView(
                    'school.backEnd.examination.exam_schedule_print',
                    [
                        'exam_schedules' => $exam_schedules,
                        'exam_type' => $exam_type,
                        'class_name' => $class_name,
                        'academic_year' => $academic_year,
                        'section_name' => $section_name,
                    ]
                )->setPaper('A4', 'landscape');
                return $pdf->stream('EXAM_SCHEDULE.pdf');
            } else {
                Toastr::error('Operation Failed', 'Failed');
                return redirect()->back();
            }
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }
}
