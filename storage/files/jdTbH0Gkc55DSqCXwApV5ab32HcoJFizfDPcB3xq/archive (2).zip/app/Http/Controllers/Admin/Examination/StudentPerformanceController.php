<?php

namespace App\Http\Controllers\Admin\Examination;

use App\Http\Controllers\Controller;
use App\Models\TestLineEntries;
use App\Models\TestMaster;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;
use Brian2694\Toastr\Facades\Toastr;



class StudentPerformanceController extends Controller
{
    public function index()
    {
        $sessionData = Session::get('search-performance');
        return view('school.backEnd.student-performance.index', compact('sessionData'));
    }
    // Search
    public function search(Request $request)
    {
        $apiUrl = env('THIRD_PARTY_API_URL');
        $colors = $this->colors();

        $board_id = $request->board;
        $medium_id = $request->medium;
        $standard_id = $request->standard;
        $student_id = $request->student;



        // Store the data in the session
        Session::put('search-performance', [
            'board_id' => $board_id,
            'medium_id' => $medium_id,
            'standard_id' => $standard_id,
            'student_id' => $student_id
        ]);

        // Called API
        $getStudentDetails = $this->ApiResponse('get', $apiUrl, 'getStudentDetails?student_id=' . $student_id);
        $studentDetails = $getStudentDetails['status'] == 200 ? $getStudentDetails['result'] : null;

        // Exam Level Wise Score 
        $exam_levels = ['Beginner', 'Intermediate', 'Expert'];
        $exam_level_wise_score = [];
        foreach ($exam_levels as $level) {
            $level_average = 0;
            $marks_query = TestLineEntries::whereHas('test_master', function ($query) use ($student_id, $board_id, $medium_id, $standard_id, $level) {
                $query->where('student_code', $student_id)
                    ->where('board_code', $board_id)
                    ->where('medium_code', $medium_id)
                    ->where('standard_code', $standard_id)
                    ->where('exam_level', $level);
            });
            $total_marks = $marks_query->sum('queMarks');
            $received_marks = $marks_query->where('isCorrect', 'true')->sum('queMarks');
            if ($total_marks !== 0) {
                $level_average = ($received_marks / $total_marks) * 100;
            }
            $level_average = number_format($level_average, 2);
            if ($level_average > 0) {
                $exam_level_wise_score[$level] = $level_average;
            }
        }

        // Call API
        $requestBody = [
            'standardCode' => $standard_id,
            'mediumCode' => $medium_id,
            'boardCode' => $board_id
        ];
        $getSubjectListByStdMedBoard = $this->ApiResponse('post', $apiUrl, 'getSubjectListByStdMedBoard', $requestBody);
        $subjectListByStdMedBoard = $getSubjectListByStdMedBoard['status'] == 200 ? $getSubjectListByStdMedBoard['result'] : null;

        // Bar Chart
        $subjectNames = [];
        $subjectWithMarks = [];
        $subject_wise_chart = [];
        $subjectWisePerformance = [];
        $chapterWisePerformance = [];
        if ($subjectListByStdMedBoard) {
            $subjects = $subjectListByStdMedBoard['result'];
            if (!empty($subjects)) {
                foreach ($subjects as $subject) {
                    $total_average = 0;
                    $subjectNames[] = $subject['subjectName'];
                    $subject_marks = TestLineEntries::where('subjectCode', $subject['subjectCode'])
                        ->whereHas('test_master', function ($query) use ($student_id, $board_id, $medium_id, $standard_id) {
                            $query->where('student_code', $student_id)
                                ->where('board_code', $board_id)
                                ->where('medium_code', $medium_id)
                                ->where('standard_code', $standard_id);
                        });
                    $total_subject_marks = $subject_marks->sum('queMarks');
                    $total_subject_recieved_marks = $subject_marks->where('isCorrect', 'true')->sum('queMarks');
                    if ($total_subject_marks !== 0) {
                        $total_average = ($total_subject_recieved_marks / $total_subject_marks) * 100;
                    }
                    $total_average = number_format($total_average, 2);
                    $subject_wise_chart[]  = $total_average;
                    $subjectWithMarks[] = [
                        'subject_code' => $subject['subjectCode'],
                        'subject_name' => $subject['subjectName'],
                        'recieved_marks' => $total_average
                    ];
                    // Analysis 
                    $subjectWisePerformance[] = $this->subjectPerformance($total_subject_marks, $total_subject_recieved_marks, $subject);


                    // Called API
                    $chRequestBody = ['subjectCode' => $subject['subjectCode']];
                    $getChaptersBySubject = $this->ApiResponse('post', $apiUrl, 'getChaptersBySubject', $chRequestBody);
                    $chaptersBySubject = $getChaptersBySubject['status'] == 200 ? $getChaptersBySubject['result'] : null;

                    if ($chaptersBySubject) {
                        $chapters = $chaptersBySubject['result'];
                        if (!empty($chapters)) {
                            foreach ($chapters as $chapter) {
                                $chapter_marks = TestLineEntries::where('chapterCode', $chapter['id'])
                                    ->whereHas('test_master', function ($query) use ($student_id, $board_id, $medium_id, $standard_id) {
                                        $query->where('student_code', $student_id)
                                            ->where('board_code', $board_id)
                                            ->where('medium_code', $medium_id)
                                            ->where('standard_code', $standard_id);
                                    });
                                $total_chapter_marks = $subject_marks->sum('queMarks');
                                $total_chapter_recieved_marks = $subject_marks->where('isCorrect', 'true')->sum('queMarks');

                                $chapterWisePerformance[] = $this->chapterPerformance($total_chapter_marks, $total_chapter_recieved_marks, $chapter);
                            }
                        }
                    }
                }
            }
        }
        return view('school.backEnd.student-performance.view', compact('studentDetails', 'board_id', 'medium_id', 'standard_id', 'student_id', 'exam_level_wise_score', 'subjectNames', 'subject_wise_chart', 'subjectWithMarks', 'subjectWisePerformance', 'chapterWisePerformance', 'colors'));
    }
    // Clear Search
    public function clear_search()
    {
        Session::forget('search-performance');
        return response()->json(['success' => true, 'redirect_url' => url('student-performance')]);
    }
    // Subject Details
    public function subject_details(Request $request)
    {
        $board_id = $request->board;
        $medium_id = $request->medium;
        $standard_id = $request->standard;
        $student_id = $request->student;
        $subject_id = $request->subject;

        $isExist = TestMaster::where('student_code', $student_id)
            ->where('board_code', $board_id)
            ->where('medium_code', $medium_id)
            ->where('standard_code', $standard_id)
            ->whereHas('test_line_entries', function ($query) use ($subject_id) {
                $query->where('subjectCode', $subject_id);
            })
            ->exists();


        if ($isExist) {
            return view('school.backEnd.student-performance.subject-details', compact('board_id', 'medium_id', 'standard_id', 'student_id', 'subject_id'));
        } else {
            Toastr::error('Result not found');
            return redirect('/student-performance');
        }
    }
    // Student Details View
    public function subject_details_view(Request $request)
    {
        $board_id = $request->board;
        $medium_id = $request->medium;
        $standard_id = $request->standard;
        $student_id = $request->student;
        $subject_id = $request->subject;
        $test_type = $request->testType;
        $date = $request->date;
        $formattedDate = Carbon::createFromFormat('m-d-Y', $date)->format('Y-m-d');
        $startOfDay = $formattedDate . ' 00:00:00';
        $endOfDay = $formattedDate . ' 23:59:59';

        $test_list = TestMaster::with(['test_line_entries' => function ($query) use ($subject_id) {
            $query->where('subjectCode', $subject_id);
        }])
            ->where('student_code', $student_id)
            ->where('board_code', $board_id)
            ->where('medium_code', $medium_id)
            ->where('standard_code', $standard_id)
            ->where('test_type', $test_type)
            ->where('created_at', '>=', $startOfDay)
            ->where('created_at', '<=', $endOfDay)
            ->get();

        return view('school.backEnd.student-performance.subject-details-view', compact('test_list'));
    }




    // Colors Array
    public function colors()
    {
        $colors = [
            '#00008B', // dark blue
            '#8B0000', // dark red
            '#006400', // dark green
            '#B8860B', // dark goldenrod
            '#4B0082', // indigo
            '#8B008B', // dark magenta
            '#556B2F', // dark olive green
            '#FF8C00', // dark orange
            '#9932CC', // dark orchid
            '#8B4513', // saddle brown
            '#2F4F4F', // dark slate gray
            '#008B8B', // dark cyan
            '#483D8B', // dark slate blue
            '#2E8B57', // sea green
            '#6A5ACD', // slate blue
            '#8B0000', // dark red
            '#3CB371', // medium sea green
            '#800000', // maroon
            '#000080', // navy
            '#191970', //
        ];
        return $colors;
    }
    // Handle API Errors
    function handleApiError($response)
    {
        $statusCode = $response->status();
        $responseBody = $response->body();

        Log::error('Failed to fetch student details', ['status' => $statusCode, 'response' => $responseBody]);

        switch ($statusCode) {
            case 400:
                $message = 'Bad request. Please check the student ID and try again.';
                break;
            case 401:
                $message = 'Unauthorized. Please check your API credentials.';
                break;
            case 404:
                $message = 'Data not found.';
                break;
            case 500:
                $message = 'Server error. Please try again later.';
                break;
            default:
                $message = 'An unexpected error occurred. Please try again later.';
                break;
        }
        return [
            'status' => $statusCode,
            'message' => $message
        ];
    }
    // API Response
    public function ApiResponse($method = '', $apiUrl = '', $endpoint = '', $reqBody = [])
    {
        try {
            $getResponse = $method == 'get' ? Http::$method($apiUrl . $endpoint) : Http::$method($apiUrl . $endpoint, $reqBody);
            if ($getResponse->successful()) {
                return [
                    'status' => $getResponse->status(),
                    'result' => $getResponse->json()
                ];
            } else {
                return $this->handleApiError($getResponse);
            }
        } catch (\Exception $e) {
            Log::error('Exception while fetching student details', ['exception' => $e->getMessage()]);
            return [
                'status' => 500,
                'message' => $e->getMessage()
            ];
        }
    }
    // Student Performance
    protected function subjectPerformance($total_subject_marks, $total_subject_recieved_marks, $subject)
    {
        $status = '';
        if ($total_subject_marks == 0) {
            $status = '<span class="badge badge-secondary px-3 py-2">No Status</span>';
        } else {
            if ($total_subject_recieved_marks > ($total_subject_marks / 3)) {
                $status = '<span class="badge badge-success px-3 py-2">Strong</span>';
            } else {
                $status = '<span class="badge badge-danger px-3 py-2">Weak</span>';
            }
        }
        return [
            'subject_code' => $subject['subjectCode'],
            'subject_name' => $subject['subjectName'],
            'recieved_marks' => $total_subject_recieved_marks,
            'total_marks' => $total_subject_marks,
            'status' => $status
        ];
    }
    // Chapter Performance
    protected function chapterPerformance($total_chapter_marks, $total_chapter_recieved_marks, $chapter)
    {
        $status = '';
        if ($total_chapter_marks == 0) {
            $status = '<span class="badge badge-secondary px-3 py-2">No Status</span>';
        } else {
            if ($total_chapter_recieved_marks > ($total_chapter_marks / 3)) {
                $status = '<span class="badge badge-success px-3 py-2">Strong</span>';
            } else {
                $status = '<span class="badge badge-danger px-3 py-2">Weak</span>';
            }
        }
        return [
            'chapter_code' => $chapter['id'],
            'chapter_name' => $chapter['chapter'],
            'recieved_marks' => $total_chapter_recieved_marks,
            'total_marks' => $total_chapter_marks,
            'status' => $status
        ];
    }
}
