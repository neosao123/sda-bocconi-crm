<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\School\AccountVerify;
use App\Models\SuperAdmin\SchoolAccount;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Http;
use Stancl\Tenancy\Tenancy;
use App\Mail\AccountActivation;
use App\Models\SchoolMaster;
use App\Models\Tenant;
use App\Rules\UniqueSubdomain;
use App\User;
use Illuminate\Support\Facades\Artisan;


class RegisterController extends Controller
{

  public function index()
  {
    $indianStates = [
      "Andhra Pradesh",
      "Arunachal Pradesh",
      "Assam",
      "Bihar",
      "Chhattisgarh",
      "Goa",
      "Gujarat",
      "Haryana",
      "Himachal Pradesh",
      "Jharkhand",
      "Karnataka",
      "Kerala",
      "Madhya Pradesh",
      "Maharashtra",
      "Manipur",
      "Meghalaya",
      "Mizoram",
      "Nagaland",
      "Odisha (Orissa)",
      "Punjab",
      "Rajasthan",
      "Sikkim",
      "Tamil Nadu",
      "Telangana",
      "Tripura",
      "Uttar Pradesh",
      "Uttarakhand",
      "West Bengal"
    ];

    return view('account.create', compact('indianStates'));
  }

  public function create(Request $r)
  {
    $r->validate([
      'full_name' => 'required|string|min:2|max:255|regex:/^[a-zA-Z\s]+$/',
      'email' => 'required|email|max:255|unique:school_accounts',
      'phone' => 'required|string|digits:10|unique:school_accounts',
      'school_name' => 'required|string|min:2|max:255|regex:/^[a-zA-Z\s]+$/',
      'domain' => ['required', 'string', 'alpha', 'min:3', 'max:15', new UniqueSubdomain],
      'address' => [
        'required',
        'min:4',
        'max:800'
      ],
      'city' => [
        'required',
        'min:2',
        'max:50',
        'regex:/^[a-zA-Z\s]+$/'
      ],
      'state' => 'required|string|regex:/^[a-zA-Z\s]+$/',
      'postalcode' => 'required|numeric|digits:6',
      'country' => 'required|string|regex:/^[a-zA-Z\s]+$/'
    ], [
      'full_name.required' => 'Full name is required.',
      'full_name.string' => 'Full name must be a string.',
      'full_name.min' => 'Full name must be at least 2 characters.',
      'full_name.max' => 'Full name may not be greater than 255 characters.',
      'full_name.alpha' => 'Full name may only contain letters.',
      'full_name.regex' => 'Full name may only contain letters and spaces.',
      'last_name.required' => 'Last name is required.',
      'last_name.string' => 'Last name must be a string.',
      'last_name.min' => 'Last name must be at least 2 characters.',
      'last_name.max' => 'Last name may not be greater than 255 characters.',
      'last_name.alpha' => 'Last name may only contain letters.',
      'email.required' => 'Email is required.',
      'email.email' => 'Email must be a valid email address.',
      'email.max' => 'Email may not be greater than 255 characters.',
      'email.unique' => 'Email has already been taken.',
      'phone.required' => 'Phone number is required.',
      'phone.string' => 'Phone number must be a string.',
      'phone.digits' => 'Phone number mast be 10 digits.',
      'phone.unique' => 'Phone number has already been taken.',
      'school_name.required' => 'School name is required.',
      'school_name.string' => 'School name must be a string.',
      'school_name.min' => 'School name must be at least 2 characters.',
      'school_name.max' => 'School name may not be greater than 255 characters.',
      'school_name.regex' => 'School name may only contain letters and spaces.',
      'domain.required' => 'Domain is required.',
      'domain.string' => 'Domain must be a string.',
      'domain.alpha' => 'Domain may only contain letters.',
      'domain.min' => 'Domain must be at least 3 characters.',
      'domain.max' => 'Domain may not be greater than 15 characters.',
      'address.required' => 'Address is required.',
      'address.min' => 'Address must be at least 4 characters.',
      'address.max' => 'Address may not be greater than 800 characters.',

      'city.required' => 'City is required.',
      'city.min' => 'City must be at least 2 characters.',
      'city.max' => 'City may not be greater than 50 characters.',
      'city.regex' => 'City may only contain letters and spaces.',
      'state.required' => 'State is required.',
      'state.string' => 'State must be a string.',
      'state.regex' => 'State may only contain letters and spaces.',
      'postalcode.required' => 'Postal code is required.',
      'postalcode.numeric' => 'Postal code must be a number.',
      'postalcode.digits' => 'Postal code exact 6 characters.',
      'country.required' => 'Country is required.',
      'country.string' => 'Country must be a string.',
      'country.regex' => 'Country may only contain letters and spaces.',
    ]);


    $token = Str::random(32);
    try {

      $token = Str::random(40);
      $verify_url = url('account/verify/' . $token);

      $schoolAccount = new SchoolAccount();
      $schoolAccount->domain = $r->domain . "." . config('tenancy.central_domains')[1];
      $schoolAccount->school_name = $r->school_name;
      $schoolAccount->full_name = $r->full_name;
      $schoolAccount->email = $r->email;
      $schoolAccount->phone = $r->phone;
      $schoolAccount->address = $r->address;
      $schoolAccount->city = $r->city;
      $schoolAccount->state = $r->state;
      $schoolAccount->postalcode = $r->postalcode;
      $schoolAccount->country = $r->country;
      $schoolAccount->token = $token;
      $schoolAccount->save();

      Mail::to($r->email)->send(new AccountVerify($r->name, $token, $verify_url, $r->school_name,));

      DB::commit();
      return redirect('account/create')->with('success', 'Account created  successfully!');
    } catch (\Exception $ex) {
      DB::rollback();
      Log::debug("New Account Verification error" . $ex->getMessage());
      return redirect('account/create')->with('error', "Failed to create account");
    }
  }

  public function token($token)
  {
    return view('account.token', compact('token'));
  }

  public function verify(Request $r)
  {
    try {
      $token = $r->traceid;
      if ($token && $token != "") {
        $schoolAccount = SchoolAccount::where('token', $token)->where('is_email_verified', 0)->first();
        if (empty($schoolAccount)) {
          return response()->json(["message" => "Invalid verification url, please confirm that the verifcation url is valid."], 400);
        }

        if ($schoolAccount->is_email_verified == 1) {
          return response()->json(["message" => "Your account is already verifed and configured already."], 400);
        }
        $school_id = $schoolAccount->id;

        $schoolArray = [
          "school_name" => $schoolAccount->school_name,
          "first_name" => $schoolAccount->first_name,
          "last_name" => $schoolAccount->last_name,
          "full_name" => "{$schoolAccount->first_name} {$schoolAccount->last_name}",
          "email" => $schoolAccount->email,
          "phone" => $schoolAccount->phone,
          "password" => $schoolAccount->password,
          "school_id" => $school_id
        ];

        $tenant = Tenant::create($schoolArray);
        if ($tenant) {
          $tenant_id = $tenant->id;
          // create tenant domain
          $tenant->createDomain(['domain' => $schoolAccount->domain]);

          // update the school record with tenant id at mobile app api
          $apiUrl = env('THIRD_PARTY_API_URL');
          $response = Http::post($apiUrl . 'addUpdateSchool', [
            'tenant_id' => $tenant_id,
            'schoolName' => $schoolAccount->school_name,
            'schoolLogo' => "",
            'slogan' => "",
            'distributorCode' => "",
            'code' => ""
          ]);
          $responseBody = $response->body();
          Log::debug('school-mobile-app-api fail result => ' . $responseBody);

          $response = Http::get(url('api/sync-tenant'), [
            'school_id' => $school_id,
            'tenant_id' => $tenant_id,
          ]);
          $responseBody = $response->body();
          Log::debug('sync school fail result => ' . $responseBody);

          //return reponse
          return response()->json(["message" => "Configuration successful! Your request is pending verification by an administrator."], 200);
        }
        return response()->json(["message" => "Something went wrong while configuring your school"], 400);
      }
      return response()->json(["message" => "Invalid verification url, please confirm that the verifcation url is valid"], 400);
    } catch (\Exception $ex) {
      Log::debug("New Account Verification error => " . $ex);
      return response()->json(["message" => "Failed to process your request due to " . $ex->getMessage() . ". Please try again by refreshing this page"], 400);
    }
  }
}
