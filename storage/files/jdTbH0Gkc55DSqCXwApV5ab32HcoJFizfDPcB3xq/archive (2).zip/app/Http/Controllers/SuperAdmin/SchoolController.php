<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\SuperAdmin\SchoolAccount;
use App\Models\SuperAdmin\SubscriptionPlan;
use App\Models\SuperAdmin\SchoolSubscription;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;
use App\Mail\School\AccountVerify;
use App\Mail\AccountActivation;
use App\Mail\AccountReActivate;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Rules\UniqueSubdomain;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use App\User;
use App\SmSchool;
use App\SmStaff;

class SchoolController extends Controller
{
    public function __construct() {}

    public function index(Request $request)
    {
        try {
            $school = SchoolAccount::select("school_accounts.*", "subscription_plans.title", "schoolsubscription.subscription_id as subId")
                ->leftJoin("schoolsubscription", function ($join) {
                    $join->on("schoolsubscription.school_id", "=", "school_accounts.id")
                        ->where("schoolsubscription.is_expired", 0);
                })
                ->leftJoin("subscription_plans", "subscription_plans.id", "=", "schoolsubscription.subscription_id")
                ->whereNotNull('school_accounts.school_subscription_id')
                ->where('school_accounts.is_email_verified', 1)
                ->get();

            return view('superadmin.school.list', compact('school'));
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    public function view(Request $r)
    {
        try {
            $school = SchoolAccount::select("school_accounts.*", "subscription_plans.title", "schoolsubscription.subscription_id as subId")
                ->leftJoin("schoolsubscription", function ($join) {
                    $join->on("schoolsubscription.school_id", "=", "school_accounts.id")
                        ->where("schoolsubscription.is_expired", 0);
                })
                ->leftJoin("subscription_plans", "subscription_plans.id", "=", "schoolsubscription.subscription_id")
                ->where("school_accounts.id", $r->id)
                ->first();
            if ($school) {
                return view('superadmin.school.view', compact('school'));
            } else {
                Toastr::error('School not found');
                return redirect('schools');
            }
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    // Developer: Shreyas M
    // Activation View Page
    public function viewActivate(Request $r)
    {
        try {
            $school = SchoolAccount::select("school_accounts.*")
                ->where("school_accounts.id", $r->id)
                ->where('active_status', 0)
                ->where('is_email_verified', 1)
                ->first();
            $subscriptionPlan = SubscriptionPlan::where('isactive', 1)->where('isdelete', 0)->get();
            if ($school && !empty($subscriptionPlan)) {
                return view('superadmin.school.view-activate', compact('school', 'subscriptionPlan'));
            } else {
                Toastr::error('School or subscription plan not found');
                return redirect('/dashboard');
            }
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    // Developer: Shreyas M
    // School Activation Logic
    public function activate(Request $r)
    {
        // Validate the request
        $validated = $r->validate([
            'school_id' => 'required|exists:school_accounts,id',
            'subscription_plan' => 'required|exists:subscription_plans,id',
        ]);

        try {
            $school = SchoolAccount::find($r->school_id);
            $selectedPlan = SubscriptionPlan::find($r->subscription_plan);

            // Calculate subscription dates
            $startDate = Carbon::now();
            $endDate = $startDate->copy()->addMonths($selectedPlan->duration_in_month);
            $formattedStartDate = $startDate->format('Y-m-d H:i:s');
            $formattedEndDate = $endDate->format('Y-m-d H:i:s');

            if ($school && $selectedPlan) {
                $url = "https://" . $school->domain;

                // Send activation and login credentials mail
                Mail::to($school->email)->send(new AccountActivation($school->full_name, $school->email, '123456', $url, $school->school_name));

                // Create a new school subscription
                $data = [
                    'subscription_id' => $r->subscription_plan,
                    'school_id' => $r->school_id,
                    'start_date' => $formattedStartDate,
                    'end_date' => $formattedEndDate,
                    'is_active' => 1,
                    'is_delete' => 0,
                    'is_expired' => 0
                ];
                $schoolSubs = SchoolSubscription::create($data);

                if ($schoolSubs) {
                    // Update school status
                    $school->active_status = 1;
                    $school->is_enabled = 'yes';
                    $school->school_subscription_id = $schoolSubs->id;
                    $school->plan_expiry_date = $formattedEndDate;
                    $school->is_expired = 0;
                    $school->save();
                }


                tenancy()->initialize($school->tenant_id);
                $smSchool = SmSchool::find(1);
                $smSchool->school_name = $school->school_name;
                $smSchool->email = $school->email;
                $smSchool->save();

                $user = User::find(1);
                $user->email = $school->email;
                $user->username = $school->email;
                $user->save();

                $staff = SmStaff::find(1);
                $staff->email = $school->email;
                $staff->save();
                // Show success message
                Toastr::success('School activated successfully.', 'Success');
                return redirect('/schools');
            }
            // Handle the case where school or selectedPlan is not found (should not happen due to validation)
            Toastr::error('School or subscription plan not found.', 'Error');
            return redirect()->back();
        } catch (\Exception $e) {
            // Handle any other exceptions
            Toastr::error('Operation failed', 'Failed');
            return redirect()->back();
        }
    }

    // Developer: Shreyas M
    // School Re-activation List
    public function reActivate(Request $r)
    {
        try {
            $schools = SchoolAccount::where('active_status', 1)
                ->where('is_email_verified', 1)
                ->where('is_expired', 1)
                ->get();
            return view('superadmin.school.re-activate-list', compact('schools'));
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    // Developer: Shreyas M
    // School Re-activation View
    public function ViewReActivate(Request $r)
    {
        try {
            $school = SchoolAccount::where("school_accounts.id", $r->id)
                ->where('active_status', 1)
                ->where('is_email_verified', 1)
                ->where('is_expired', 1)
                ->first();
            $subscriptionPlan = SubscriptionPlan::where('isactive', 1)->where('isdelete', 0)->get();
            return view('superadmin.school.view-re-activate', compact('school', 'subscriptionPlan'));
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }
    // Developer: Shreyas M
    // Reactivate School Subscription Plan Logic
    public function reactivateSchoolPlan(Request $r)
    {
        // Validate the request
        $validated = $r->validate([
            'school_id' => 'required|exists:school_accounts,id',
            'subscription_plan' => 'required|exists:subscription_plans,id',
        ]);

        try {
            $school = SchoolAccount::find($r->school_id);
            $selectedPlan = SubscriptionPlan::find($r->subscription_plan);

            // Calculate subscription dates
            $startDate = Carbon::now();
            $endDate = $startDate->copy()->addMonths($selectedPlan->duration_in_month);
            $formattedStartDate = $startDate->format('Y-m-d H:i:s');
            $formattedEndDate = $endDate->format('Y-m-d H:i:s');

            if ($school && $selectedPlan) {
                $url = "https://" . $school->domain;
                // Send activation and login credentials mail
                Mail::to($school->email)->send(new AccountReActivate($school->full_name, $url, $school->school_name));

                // Create a new school subscription
                $data = [
                    'subscription_id' => $r->subscription_plan,
                    'school_id' => $r->school_id,
                    'start_date' => $formattedStartDate,
                    'end_date' => $formattedEndDate,
                    'is_active' => 1,
                    'is_delete' => 0,
                    'is_expired' => 0
                ];
                $schoolSubs = SchoolSubscription::create($data);

                if ($schoolSubs) {
                    // Update school status
                    $school->school_subscription_id = $schoolSubs->id;
                    $school->plan_expiry_date = $formattedEndDate;
                    $school->is_expired = 0;
                    $school->save();
                }
                // Show success message
                Toastr::success('School activated successfully.', 'Success');
                return redirect('/schools');
            }
            // Handle the case where school or selectedPlan is not found (should not happen due to validation)
            Toastr::error('School or subscription plan not found.', 'Error');
            return redirect()->back();
        } catch (\Exception $e) {
            // Handle any other exceptions
            Toastr::error('Operation failed', 'Failed');
            return redirect()->back();
        }
    }

    // Developer: Shreyas M
    // School Last Activation Plan History
    public function activateHistory()
    {
        try {
            $subQuery = DB::table('schoolsubscription')
                ->select('school_id', DB::raw('MAX(id) as latest_id'))
                ->groupBy('school_id');

            $school = SchoolAccount::query()
                ->select('school_accounts.*', 'subscription_plans.title')
                ->leftJoinSub($subQuery, 'latest_subscription', function ($join) {
                    $join->on('school_accounts.id', '=', 'latest_subscription.school_id');
                })
                ->leftJoin('schoolsubscription', 'schoolsubscription.id', '=', 'latest_subscription.latest_id')
                ->leftJoin('subscription_plans', 'subscription_plans.id', '=', 'schoolsubscription.subscription_id')
                ->get();

            return view('superadmin.school.activation-history', compact('school'));
        } catch (\Exception $e) {
            Toastr::error($e->getMessage(), 'Failed');
            return redirect()->back();
        }
    }

    // Developer: ShreyasM
    // For Active & Deactive Class
    public function suspendActivate(Request $r)
    {
        try {
            $school = SchoolAccount::find($r->id);
            if ($school->active_status == 0) {
                $school->active_status = 1;
                $school->save();
                Toastr::success('School reactivated successfully.', 'Success');
            } else {
                $school->active_status = 0;
                $school->save();
                Toastr::success('School suspended successfully.', 'Success');
            }
            return redirect()->back();
        } catch (\Exception $e) {
            Toastr::error($e->getMessage(), 'Failed');
            return redirect()->back();
        }
    }

    // Developer: ShreyasM
    // Registered School - View 
    public function viewReg(Request $r)
    {
        try {
            $school = SchoolAccount::where('id', $r->id)->where('active_status', 0)->where('is_email_verified', 0)
                ->where('school_subscription_id', null)->first();
            if ($school) {
                return view('superadmin.school.registeredschool.view-reg', compact('school'));
            } else {
                Toastr::error('School not found', 'Failed');
                return redirect('/dashboard');
            }
        } catch (\Exception $e) {
            Toastr::error($e->getMessage(), 'Failed');
            return redirect()->back();
        }
    }
    // Developer: ShreyasM
    // Registered School - Edit
    public function editReg(Request $r)
    {
        try {
            $school = SchoolAccount::where('id', $r->id)->where('active_status', 0)->where('is_email_verified', 0)
                ->where('school_subscription_id', null)->first();
            if ($school) {
                $indianStates = [
                    "Andhra Pradesh",
                    "Arunachal Pradesh",
                    "Assam",
                    "Bihar",
                    "Chhattisgarh",
                    "Goa",
                    "Gujarat",
                    "Haryana",
                    "Himachal Pradesh",
                    "Jharkhand",
                    "Karnataka",
                    "Kerala",
                    "Madhya Pradesh",
                    "Maharashtra",
                    "Manipur",
                    "Meghalaya",
                    "Mizoram",
                    "Nagaland",
                    "Odisha (Orissa)",
                    "Punjab",
                    "Rajasthan",
                    "Sikkim",
                    "Tamil Nadu",
                    "Telangana",
                    "Tripura",
                    "Uttar Pradesh",
                    "Uttarakhand",
                    "West Bengal"
                ];
                return view('superadmin.school.registeredschool.edit-reg', compact('school', 'indianStates'));
            } else {
                Toastr::error('School not found', 'Failed');
                return redirect('/dashboard');
            }
        } catch (\Exception $e) {
            Toastr::error($e->getMessage(), 'Failed');
            return redirect()->back();
        }
    }
    // Developer: ShreyasM
    // Registered School - Update
    public function updateReg(Request $r)
    {
        $r->validate([
            'school_id' => 'required',
            'full_name' => 'required|string|min:2|max:255|regex:/^[a-zA-Z\s]+$/',
            'email' => [
                'required',
                'email',
                'max:255',
                Rule::unique('school_accounts')->ignore($r->school_id),
            ],
            'phone' => [
                'required',
                'string',
                'digits:10',
                Rule::unique('school_accounts')->ignore($r->school_id),
            ],
            'school_name' => 'required|string|min:2|max:255|regex:/^[a-zA-Z\s]+$/',
            'domain' => ['required', 'string', 'alpha', 'min:3', 'max:15', new UniqueSubdomain($r->school_id)],
            'address' => [
                'required',
                'min:4',
                'max:800'
            ],
            'city' => [
                'required',
                'min:2',
                'max:50',
                'regex:/^[a-zA-Z\s]+$/'
            ],
            'state' => 'required|string',
            'postalcode' => 'required|numeric|digits:6',
            'country' => 'required|string|regex:/^[a-zA-Z\s]+$/'
        ], [
            'full_name.required' => 'Full name is required.',
            'full_name.string' => 'Full name must be a string.',
            'full_name.min' => 'Full name must be at least 2 characters.',
            'full_name.max' => 'Full name may not be greater than 255 characters.',
            'full_name.alpha' => 'Full name may only contain letters.',
            'full_name.regex' => 'Full name may only contain letters and spaces.',
            'last_name.required' => 'Last name is required.',
            'last_name.string' => 'Last name must be a string.',
            'last_name.min' => 'Last name must be at least 2 characters.',
            'last_name.max' => 'Last name may not be greater than 255 characters.',
            'last_name.alpha' => 'Last name may only contain letters.',
            'email.required' => 'Email is required.',
            'email.email' => 'Email must be a valid email address.',
            'email.max' => 'Email may not be greater than 255 characters.',
            'email.unique' => 'Email has already been taken.',
            'phone.required' => 'Phone number is required.',
            'phone.string' => 'Phone number must be a string.',
            'phone.digits' => 'Phone number mast be 10 digits.',
            'phone.unique' => 'Phone number has already been taken.',
            'school_name.required' => 'School name is required.',
            'school_name.string' => 'School name must be a string.',
            'school_name.min' => 'School name must be at least 2 characters.',
            'school_name.max' => 'School name may not be greater than 255 characters.',
            'school_name.regex' => 'School name may only contain letters and spaces.',
            'domain.required' => 'Domain is required.',
            'domain.string' => 'Domain must be a string.',
            'domain.alpha' => 'Domain may only contain letters.',
            'domain.min' => 'Domain must be at least 3 characters.',
            'domain.max' => 'Domain may not be greater than 15 characters.',
            'address.required' => 'Address is required.',
            'address.min' => 'Address must be at least 4 characters.',
            'address.max' => 'Address may not be greater than 800 characters.',
            'city.required' => 'City is required.',
            'city.min' => 'City must be at least 2 characters.',
            'city.max' => 'City may not be greater than 50 characters.',
            'city.regex' => 'City may only contain letters and spaces.',
            'state.required' => 'State is required.',
            'state.string' => 'State must be a string.',
            'postalcode.required' => 'Postal code is required.',
            'postalcode.numeric' => 'Postal code must be a number.',
            'postalcode.digits' => 'Postal code exact 6 characters.',
            'country.required' => 'Country is required.',
            'country.string' => 'Country must be a string.',
            'country.regex' => 'Country may only contain letters and spaces.',
        ]);
        try {
            $isEmailSend = false;
            $schoolAccount = SchoolAccount::find($r->school_id);
            if (strtolower($r->email) !== strtolower($schoolAccount->email)) {
                $isEmailSend = true;
            }
            $schoolAccount->domain = $r->domain . "." . config('tenancy.central_domains')[1];
            $schoolAccount->school_name = $r->school_name;
            $schoolAccount->full_name = $r->full_name;
            $schoolAccount->email = $r->email;
            $schoolAccount->phone = $r->phone;
            $schoolAccount->address = $r->address;
            $schoolAccount->city = $r->city;
            $schoolAccount->state = $r->state;
            $schoolAccount->postalcode = $r->postalcode;
            $schoolAccount->country = $r->country;
            if ($isEmailSend) {
                $token = Str::random(40);
                $verify_url = url('account/verify/' . $token);
                $schoolAccount->token = $token;
                Mail::to($r->email)->send(new AccountVerify($r->name, $token, $verify_url, $r->school_name));
                Toastr::success('Successfully updated & sending new email for verification', 'Success');
                $schoolAccount->save();
                DB::commit();
                return redirect('/dashboard');
            }
            $schoolAccount->save();
            DB::commit();
            Toastr::success('Successfully updated', 'Success');
            return redirect('/dashboard');
        } catch (\Exception $e) {
            Toastr::error($e->getMessage(), 'Failed');
            return redirect()->back();
        }
    }
    // Developer: ShreyasM
    // Registered School - Delete
    public function deleteReg(Request $r)
    {
        try {
            SchoolAccount::destroy($r->id);
            Toastr::success('Operation successful', 'Success');
            return redirect()->back();
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }
}
