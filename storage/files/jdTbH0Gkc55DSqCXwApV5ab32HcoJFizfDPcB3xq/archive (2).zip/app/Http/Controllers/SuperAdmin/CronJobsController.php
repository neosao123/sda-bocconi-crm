<?php


namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\SuperAdmin\SchoolAccount;
use App\Models\SuperAdmin\SchoolSubscription;
use Carbon\Carbon;

class CronJobsController extends Controller
{
    public function expireSchoolSubscription()
    {
        try {
            $todays_date = Carbon::now()->format('Y-m-d H:i:s');
            // Update SchoolAccount records
            SchoolAccount::where('plan_expiry_date', '<', $todays_date)
                ->update(['is_expired' => 1]);
            // Update SchoolSubscription records
            $schoolsToUpdate = SchoolAccount::where('plan_expiry_date', '<', $todays_date)->get();
            foreach ($schoolsToUpdate as $school) {
                $subscription = SchoolSubscription::find($school->school_subscription_id);
                $subscription->is_expired = 1;
                $subscription->save();
            }
            return response()->json(['status' => 200, 'message' => 'success'], 200);
        } catch (\Exception $e) {
            return response()->json(['status' => 500, 'message' => $e->getMessage()], 500);
        }
    }
}
