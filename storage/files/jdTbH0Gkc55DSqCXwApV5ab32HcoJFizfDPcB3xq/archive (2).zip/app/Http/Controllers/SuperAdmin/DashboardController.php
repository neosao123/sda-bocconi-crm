<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SuperAdmin\SchoolAccount;
use App\Models\SuperAdmin\SubscriptionPlan;

class DashboardController extends Controller
{
    public function index()
    {

        $totalSchool = SchoolAccount::select("school_accounts.*", "subscription_plans.title", "schoolsubscription.subscription_id as subId")
            ->leftJoin("schoolsubscription", function ($join) {
                $join->on("schoolsubscription.school_id", "=", "school_accounts.id")
                    ->where("schoolsubscription.is_expired", 0);
            })
            ->leftJoin("subscription_plans", "subscription_plans.id", "=", "schoolsubscription.subscription_id")
            ->whereNotNull('school_accounts.school_subscription_id')
            ->where('school_accounts.is_email_verified', 1)->count();
        $totalSubscription = SubscriptionPlan::where("isdelete", 0)->where('isactive', 1)
            ->count();
        $schoolDetails = SchoolAccount::where("active_status", 0)
            ->where('is_email_verified', 1)
            ->where('school_subscription_id', null)
            ->orderBy('id', 'DESC')
            ->paginate(10);

        $regSchool = SchoolAccount::where('active_status', 0)
            ->where('is_email_verified', 0)
            ->where('school_subscription_id', null)
            ->orderBy('id', 'DESC')
            ->get();


        return view('superadmin.dashboard', compact('totalSchool', 'totalSubscription', 'schoolDetails', 'regSchool'));
    }
}
