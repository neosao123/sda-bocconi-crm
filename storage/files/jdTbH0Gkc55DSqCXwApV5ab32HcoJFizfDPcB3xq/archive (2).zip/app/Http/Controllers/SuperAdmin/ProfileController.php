<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\SuperAdmin\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use Brian2694\Toastr\Facades\Toastr;

class ProfileController extends Controller
{

    public function index()
    {
        if (!(Auth::user())) {
            return redirect('/');
        }
        $details = Auth::user();
        return view('superadmin.profile.index', compact('details'));
    }

    public function update(Request $r)
    {
        $r->validate([
            'name' => 'required|regex:/^[A-Za-z\s]+$/',
            'email' => [
                'required',
                'email',
                'regex:/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/',
                Rule::unique('users')->ignore(Auth::user()->id),
            ],
            'avatar' => 'nullable|image|mimes:jpeg,png,jpg,gif',
        ], [
            'name.required' => 'Name is required.',
            'name.regex' => 'The name must only contain alphabets and spaces.',
            'email.required' => 'The email is required.',
            'email.email' => 'Invalid email address format.',
            'email.regex' => 'Invalid email address format.',
            'avatar.image' => 'The file must be an image.',
            'avatar.mimes' => 'The image must be of type: jpeg, png, jpg, gif.',
        ]);

        $data = array(
            'name' => $r->name,
            'email' => $r->email,
        );

        // dd($r->all());
        // Check if a file was uploaded
        if ($r->hasFile('avatar')) {
            $file = $r->file('avatar');
            $path = Storage::disk('public')->putFileAs('user-avatar', $file, "avatar-" . time() . "." . $file->getClientOriginalExtension());
            $data['profile_photo'] = $path;
        }

        $userid = Auth::user()->id;
        $user = User::find($userid);
        $user->update($data);

        Toastr::success('Profile Updated Successfully.', 'Success');
        return redirect()->back();
    }

    public function deleteAvatar()
    {
        $user = Auth::user();
        $path = $user['profile_photo'];
        Storage::disk('public')->delete($path);
        $getUser = User::find($user['id']);
        $getUser->update(['profile_photo' => null]);

        Toastr::success('Avatar deleted successfully.', 'Success');
        return redirect()->back();
    }

    public function changePassword()
    {
        return view('superadmin.profile.change-password');
    }

    public function updatePassword(Request $r)
    {
        $r->validate([
            'old_password' => 'required',
            'new_password' => 'required|min:6|max:20',
            'password_confirmation' => 'required|same:new_password',
        ], [
            'old_password.required' => 'The old password is required.',
            'new_password.required' => 'The new password is required.',
            'new_password.min' => 'The new password must be at least :min characters.',
            'new_password.max' => 'The new password must not be more than :max characters.',
            'password_confirmation.required' => 'The password confirmation is required.',
            'password_confirmation.same' => 'The password confirmation must match the new password.',
        ]);

        $user = User::find(Auth::user()->id);
        if ($user) {
            if (Hash::check($r->old_password, $user->password)) {
                $user->update(['password' => Hash::make($r->new_password)]);

                Toastr::success('The password updated successfully.', 'Success');
                return redirect()->back();
            } else {
                Toastr::error('The old password is not valid.', 'Failed');
                return redirect()->back();
            }
        } else {
            Toastr::error('User does not exists.', 'Failed');
            return redirect()->back();
        }
    }
}
