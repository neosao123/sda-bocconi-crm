<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\SuperAdmin\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use PhpParser\Node\Stmt\TryCatch;
use Illuminate\Support\Facades\Hash;
use Mail;

class AuthController extends Controller
{

  public function index()
  {
    try {
      if (Auth::guard('superadmin')->check() && Auth::guard('superadmin')->user()->id != "") {
        return redirect('/dashboard');
      }
      return view('superadmin.auth.login');
    } catch (\Throwable $th) {
      return view('superadmin.auth.login');
    }
  }

  public function login(Request $r)
  {
    if ($r->isMethod('post')) {
      $r->validate([
        'email' => 'required',
        'password' => 'required',
      ]);
      $email = $r->input('email');
      $password = $r->input('password');
      $remember = $r->input('rememberme') == true ? '1' : '0';
      $result = User::where(['email' => $email])->first();
      if (empty($result)) {
        $r->session()->flash('message-danger', 'Please Enter Valid Email & Password');
        return redirect('auth/login');
      } else {
        if (Auth::guard('superadmin')->attempt(['email' => $email, 'password' => $password])) {
          Auth::login($result);
          $email = Auth::guard('superadmin')->user()->email;
          $r->session()->put('SUPERADMIN_LOGIN', true);
          if ($remember == '1') {
            Cookie::queue('email', $email, time() + (10 * 365 * 24 * 60 * 60));
            Cookie::queue('password', $password, time() + (10 * 365 * 24 * 60 * 60));
          } else {
            if (Cookie::get('email')) Cookie::queue('email', '');
            if (Cookie::get('password')) Cookie::queue('password', '');
          }
          return redirect('/dashboard');
        }
        $r->session()->flash('message-danger', 'Invalid Email or password.');
        return redirect('auth/login');
      }
    }
  }

  public function updatePassword()
  {
    $r = User::find(1);
    $r->password = Hash::make('123456');
    $r->save();
  }

  public function logout(Request $r)
  {
    Auth::logout();
    Auth::guard("superadmin")->logout();
    session()->forget('SUPERADMIN_LOGIN');
    $r->session()->flash('success', 'Successfully Logout');
    return redirect('auth/login');
  }

  public function reset(Request $r)
  {
    return view('superadmin.auth.reset');
  }

  public function reset_password(Request $r)
  {
    $r->validate([
      'email' => 'required',
    ]);
    $email = $r->input('email');
    $result = User::where("email", $email)->first();
    if ($result) {
      $token = $this->random_characters(5);
      $token .= date('Hdm');
      $sendLink = url('verify-token/' . $token);
      $details = [
        'title' => 'Mail from Learn Sushila',
        'link' => $sendLink,
      ];
      Mail::to($email)->send(new \App\Mail\SuperAdmin\ForgotAdminEmail($details));
      $data = array('reset_token' => $token);
      $resultAfterMail = $result->update($data);
      if ($resultAfterMail) {
        $r->session()->flash('success', 'Reset Link was sent to your email...');
        return redirect('/forgot-password');
      } else {
        $r->session()->flash('error', 'Some Error is Occur');
        return redirect('/forgot-password');
      }
    } else {
      $r->session()->flash('error', 'No users were found with the email address provided! Sorry cannot reset the password');
      return redirect('/forgot-password');
    }
  }

  public function verify_token_link(Request $r)
  {
    $token = $r->token;
    $result = User::where("reset_token", $token)->first();
    if ($result) {
      return view('superadmin.auth.verify', compact('result'));
    } else {
      $r->session()->flash('message', 'Password Reset Link is Expired. Please Forgot Password Again to Continue.');
      return redirect('/auth/login');
    }
  }

  public function update_password(Request $r)
  {
    $token = $r->input('token');
    $code = $r->input('code');
    $getResult = User::where("reset_token", $token)->first();
    if ($getResult) {
      $rules = [
        'password' => 'required|min:6|confirmed',
        'password_confirmation' => 'required|min:6',
      ];

      $messages = [
        'password.required' => 'Password is required',
        'password.confirmed' => 'Password does not match',
        'password_confirmation.required' => 'Password confirmation is required',
        'password_confirmation.min' => 'Password confirmation must be at least 6 characters',
      ];

      $this->validate($r, $rules, $messages);


      $data = array(
        'password' => Hash::make($r->input('password')),
        'reset_token' => null,
      );
      $result = $getResult->update($data);
      if ($result) {
        $r->session()->flash('message-success', 'Password Reset Successfully.. Please Login to Continue');
        return redirect('/auth/login');
      } else {
        $r->session()->flash('message-danger', 'Problem During Reset Password.. Please Try Again');
        return redirect('/auth/login');
      }
    } else {
      $r->session()->flash('message-danger', 'Reset Link is broken! Please try again...');
      return redirect('/auth/login');
    }
  }

  public function random_characters($n)
  {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $n; $i++) {
      $index = rand(0, strlen($characters) - 1);
      $randomString .= $characters[$index];
    }
    return $randomString;
  }
}
