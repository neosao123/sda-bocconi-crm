<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\SuperAdmin\SubscriptionPlan;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;

class SubscriptionPlanController extends Controller
{
    public function __construct()
    {
        $this->middleware('PM');
        // User::checkAuth();
    }

    public function index(Request $request)
    {
        try {
            $subscription = SubscriptionPlan::where('isactive', 1)->where('isdelete', 0)->get();
            return view('superadmin.subscription-plan.list', compact('subscription'));
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }
    public function store(Request $request)
    {

        $request->validate([
            'title' => 'required',
            'duration_in_month' => 'required|numeric',
            'total_price' => 'required|numeric',
            'isactive' => 'nullable',
        ], [
            'title.required' => 'Subscription Title is required',
            'duration_in_month.required' => 'Duration in Month is required',
            'total_price.required' => 'Total Price is required',
        ]);

        $subscription = new SubscriptionPlan();
        $subscription->title = $request->title;
        $subscription->duration_in_month = $request->duration_in_month;
        $subscription->total_price = $request->total_price;
        $result = $subscription->save();

        Toastr::success('Operation successful', 'Success');
        return redirect()->back();
    }

    public function edit(Request $request, $id)
    {
        try {
            $subscription = SubscriptionPlan::get();
            $subscriptions = SubscriptionPlan::find($id);

            return view('superadmin.subscription-plan.list', compact('subscription', 'subscriptions'));
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }
    public function update(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'duration_in_month' => 'required|numeric',
            'total_price' => 'required|numeric',
            'isactive' => 'nullable',
        ], [
            'title.required' => 'Subscription Title is required',
            'duration_in_month.required' => 'Duration in Month is required',
            'total_price.required' => 'Total Price is required',
        ]);

        $subscription = SubscriptionPlan::find($request->id);
        $subscription->title = $request->title;
        $subscription->duration_in_month = $request->duration_in_month;
        $subscription->total_price = $request->total_price;
        $result = $subscription->save();

        Toastr::success('Operation successful', 'Success');
        return redirect('subscription-plan');
    }

    public function delete(Request $request)
    {

        try {
            $subscriptionPlan = SubscriptionPlan::destroy($request->id);

            Toastr::success('Operation successful', 'Success');
            return redirect()->back();
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }
}
