<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SmExamSignature;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;

class ExamSignatureSettingsController extends Controller
{

    public function index()
    {
        $allSignature = SmExamSignature::get();
        return view('school.backEnd.examination.examSignatureSettings', compact('allSignature'));
    }

    public function store(Request $request)
    {
        foreach (gv($request, 'exam_signature') as $signature) {
            $validator = Validator::make($signature, [
                'title' => ['required', 'regex:/^[\pL\s]+$/u'],
            ]);
            if ($validator->fails()) {
                Toastr::error('Please fill all required fields & correct data.', 'Failed');
                return redirect()->back()->withErrors($validator)->withInput();
            }
        }
        try {
            foreach (gv($request, 'exam_signature') as $index => $signature) {
                $this->formatData($signature);
            }
            Toastr::success('Operation Successfully', 'Success');
            return redirect('exam-signature-settings');
        } catch (\Exception $e) {
            Toastr::error($e->getMessage(), 'Failed');
            // Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    public function update(Request $request)
    {
        foreach (gv($request, 'exam_signature') as $signature) {
            $validator = Validator::make($signature, [
                'title' => ['required', 'regex:/^[\pL\s]+$/u'],
            ]);
            if ($validator->fails()) {
                Toastr::error('Please fill all required fields & correct data.', 'Failed');
                return redirect()->back()->withErrors($validator)->withInput();
            }
        }
        try {
            $allDataDeletes = SmExamSignature::get();
            foreach ($allDataDeletes as $allDataDelete) {
                $allDataDelete->delete();
            }

            foreach (gv($request, 'exam_signature') as $signature) {
                $this->formatData($signature);
            }
            Toastr::success('Update Successfully', 'Success');
            return redirect('exam-signature-settings');
        } catch (\Exception $e) {
            Toastr::error('Operation Failed', 'Failed');
            return redirect()->back();
        }
    }

    private function formatData($request)
    {
        $storeData = new SmExamSignature();
        $storeData->title = gv($request, 'title');
        if (isset($request['image_path'])) {
            if (isset($request['signature']) && $request['signature'] instanceof \Illuminate\Http\UploadedFile) {
                $oldSignature = gv($request, 'image_path');
                if ($oldSignature && Storage::disk('public')->exists($oldSignature)) {
                    Storage::disk('public')->delete($oldSignature);
                }
                $file = $request['signature'];
                $filename = 'exam-signature-' . time() . '.' . $file->getClientOriginalExtension();
                $upload_file = Storage::disk('public')->putFileAs('upload-exam-signature', $file, $filename);
                $storeData->signature = $upload_file;
            } else {
                $storeData->signature = gv($request, 'image_path');
            }
        } else {
            if (isset($request['signature']) && $request['signature'] instanceof \Illuminate\Http\UploadedFile) {
                $file = $request['signature'];
                $filename = 'exam-signature-' . time() . '.' . $file->getClientOriginalExtension();
                $upload_file = Storage::disk('public')->putFileAs('upload-exam-signature', $file, $filename);
                $storeData->signature = $upload_file;
            }
        }
        // Additional data
        $storeData->active_status = isset($request['active_status']) ? 1 : 0;
        $storeData->school_id = auth()->user()->school_id;
        $storeData->academic_id = getAcademicId();
        // Save the record
        $storeData->save();
    }
}
