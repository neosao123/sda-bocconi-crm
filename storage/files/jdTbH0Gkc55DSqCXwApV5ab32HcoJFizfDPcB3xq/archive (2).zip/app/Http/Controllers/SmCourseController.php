<?php

namespace App\Http\Controllers;

use App\SmCourse;
use App\SmCourseCategory;
use App\SmGeneralSettings;
use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;

class SmCourseController extends Controller
{
    //
}