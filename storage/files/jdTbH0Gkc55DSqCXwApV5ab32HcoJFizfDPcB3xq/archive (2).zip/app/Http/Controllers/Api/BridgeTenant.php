<?php

namespace App\Http\Controllers\Api;


use App\Mail\AccountActivation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Artisan;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BridgeTenant extends Controller
{
  public function syncTenantSchool(Request $request)
  {
    try {
      $school_id = $request->school_id;
      $tenant_id = $request->tenant_id;

      //save tenant_id
      $schoolAccount = DB::connection("central")->table("school_accounts")->where("id", $school_id)->first();
      if ($schoolAccount) {

        $name = $schoolAccount->full_name;
        $email = $schoolAccount->email;
        $school_name = $schoolAccount->school_name;

        DB::connection("central")->table("school_accounts")
          ->where("id", $school_id)
          ->update(
            [
              'tenant_id' => $tenant_id,
              'token' => "",
              'is_email_verified' => 1,
              'active_status' => 0,
              'is_enabled' => 'no',
            ]
          );

        // Insert modules
        DB::connection("central")
          ->table("modules")
          ->insert(
            [
              'tenant_id' => $tenant_id,
              'name' => 'RolePermission',
              'isActive' => 1,
              'created_at' => date('Y-m-d H:i:s'),
              'updated_at' =>  date('Y-m-d H:i:s'),
            ]
          );
        DB::connection("central")
          ->table("modules")
          ->insert(
            [
              'tenant_id' => $tenant_id,
              'name' => 'BulkPrint',
              'isActive' => 1,
              'created_at' => date('Y-m-d H:i:s'),
              'updated_at' =>  date('Y-m-d H:i:s'),
            ]
          );
        DB::connection("central")
          ->table("modules")
          ->insert(
            [
              'tenant_id' => $tenant_id,
              'name' => 'ExamPlan',
              'isActive' => 1,
              'created_at' => date('Y-m-d H:i:s'),
              'updated_at' =>  date('Y-m-d H:i:s'),
            ]
          );

        DB::connection("central")
          ->table("modules")
          ->insert(
            [
              'tenant_id' => $tenant_id,
              'name' => 'Lesson',
              'isActive' => 1,
              'created_at' => date('Y-m-d H:i:s'),
              'updated_at' =>  date('Y-m-d H:i:s'),
            ]
          );

        DB::connection("central")
          ->table("modules")
          ->insert(
            [
              'tenant_id' => $tenant_id,
              'name' => 'Fees',
              'isActive' => 1,
              'created_at' => date('Y-m-d H:i:s'),
              'updated_at' =>  date('Y-m-d H:i:s'),
            ]
          );


        // Add School Plan
        // DB::connection("central")
        //     ->table("schoolsubscription")
        //     ->insert(
        //         [
        //             'subscription_id' => 1,
        //             'school_id' => $school_id,
        //             'start_date' => date('Y-m-d H:i:s'),
        //             'end_date' => date('Y-m-d 00:00:00', strtotime('+ 1 year')),
        //             'is_active' => 1,
        //             'is_delete' => 0,
        //             'created_at' => date('Y-m-d H:i:s'),
        //             'updated_at' =>  date('Y-m-d H:i:s'),
        //         ]
        //     );

        return response()->json(["msg" => "Sync successfull"], 200);
      } else {
        return response()->json(["msg" => "Tiger Bomb"], 200);
      }
    } catch (\Exception $exception) {
      return response()->json(["msg" => $exception->getMessage()], 200);
    }
  }
}
