<?php

namespace App\Http\Controllers\Api;

use App\Models\Tenant;
use App\Models\Domain;
use App\Models\TestLineEntries;
use App\Models\TestMaster;
use App\SmStudent;
use App\SmParent;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use App\User;
use Carbon\Carbon;

class ApiController extends Controller
{
  public function user_access(Request $r)
  {
    try {
      $email = $r->email;
      $tenant_id = $r->tenant_id;
      $role = $r->role;
      if (!$email || !$tenant_id || !$role) {
        return response()->json(['status' => 400, 'message' => 'Invalid input',], 400);
      }
      $tenant = Tenant::find($tenant_id);
      if (!$tenant) {
        return response()->json(['status' => 400, 'message' => 'Tenant not found'], 404);
      }

      $domain = Domain::where('tenant_id', $tenant_id)->first();
      if (!$domain) {
        return response()->json(['status' => 400, 'message' => 'Domain not found for the given tenant'], 404);
      }

      tenancy()->initialize($tenant);

      $student = SmStudent::where('email', "$email")->first();
      if (!$student) {
        return response()->json(['status' => 400, 'message' => 'Student not found.'], 404);
      }

      if ($role == 'student') {
        $user = User::where('id', $student->user_id)->first();
      } else if ($role == 'parent') {
        $parent = SmParent::where('id', $student->parent_id)->first();
        $user = User::where('id', $parent->user_id)->first();
      } else {
        return response()->json(['status' => 400, 'message' => 'Invalid role'], 400);
      }

      if (!$user) {
        return response()->json(['status' => 400, 'message' => 'User not found'], 404);
      }

      $url = 'https://' . $domain->domain . '/user-access/' . $user->email . '/' . $user->enc_password;
      $data['url'] = $url;
      return response()->json(['status' => 200, 'message' => 'success', 'data' => $data], 200);
    } catch (\Exception $e) {
      return response()->json(['status' => 500, 'message' => 'Error: ' . $e->getMessage()], 500);
    }
  }

  public function test_submit(Request $r)
  {
    // Check if the tenant_id header is present
    if (!$r->hasHeader('tenant-id')) {
      return response()->json([
        'status' => 'error',
        'message' => 'tenant_id header is missing.',
      ], 400);
    }
    DB::beginTransaction();
    try {
      // Retrieve tenant ID from the header
      $tenant_id = $r->header('tenant-id');
      $tenant = Tenant::find($tenant_id);
      if (!$tenant) {
        return response()->json(['message' => 'Tenant not found'], 404);
      }
      tenancy()->initialize($tenant);
      // Extract validated data
      $data = $r->except('answer_log', 'test_name');
      $data['answer_log'] = json_encode($r->answer_log);
      $data['tenant_id'] = $tenant_id;

      $count = TestMaster::where([
        'board_code' => $r->board_code,
        'medium_code' => $r->medium_code,
        'standard_code' => $r->standard_code,
        'student_code' => $r->student_code
      ])->max('id');
      $inc = 0;
      if ($count == null) {
        $inc = 1;
      } else {
        $inc = (int)$count + 1;
      }
      $data['test_name'] = 'Test ' . $inc;
      // Create test master entry
      $test_master = TestMaster::create($data);


      if ($test_master) {
        if (count($r->answer_log) > 0) {
          $test_id = $test_master->id;
          $answer_logs = $r->answer_log;
          // foreach ($answer_logs as &$entry) {
          // $entry['test_id'] = $test_id;
          // }
          foreach ($answer_logs as $entry) {
            $entry['test_id'] = $test_id;
            TestLineEntries::create($entry);
          }
          return response()->json(['status' => 'success', 'data' => $data], 200);
          // Commit the transaction
          DB::commit();
        } else {
          DB::rollBack();
          return response()->json(['status' => 'failed'], 400);
        }
      } else {
        // Rollback the transaction if test master creation fails
        DB::rollBack();
        return response()->json(['status' => 'failed'], 400);
      }
    } catch (\Exception $e) {
      // Rollback the transaction in case of any exception
      DB::rollBack();
      return response()->json(['status' => 'error', 'message' => $e->getMessage()], 500);
    }
  }

  public function get_student_test_report(Request $r)
  {
    // Check if the tenant_id header is present
    if (!$r->hasHeader('tenant-id')) {
      return response()->json([
        'status' => 400,
        'message' => 'tenant_id header is missing.',
      ], 400);
    }

    $rules = [
      'board_code' => 'required',
      'medium_code' => 'required',
      'standard_code' => 'required',
      'student_code' => 'required',
    ];
    // Create a validator instance
    $validator = Validator::make($r->all(), $rules);
    // Check if the validation fails
    if ($validator->fails()) {
      return response()->json([
        'status' => 400,
        'error' => $validator->errors()->first(),
      ], 422);
    }

    try {
      // Retrieve tenant ID from the header
      $tenant_id = $r->header('tenant-id');
      $tenant = Tenant::find($tenant_id);
      if (!$tenant) {
        return response()->json(['message' => 'Tenant not found'], 404);
      }
      tenancy()->initialize($tenant);
      // Simplify the query to focus on grouping
      $apiUrl = env('THIRD_PARTY_API_URL');
      $getSubjectListByStdMedBoard = Http::post($apiUrl . 'getSubjectListByStdMedBoard', [
        'standardCode' => $r->standard_code,
        'mediumCode' => $r->medium_code,
        'boardCode' => $r->board_code
      ]);
      if ($getSubjectListByStdMedBoard->successful()) {
        $subjectListByStdMedBoard = $getSubjectListByStdMedBoard->json();
      } else {
        $subjectListByStdMedBoard = null;
        return response()->json([
          'status' => 300,
          'message' => 'Data not found.',
        ], 200);
      }
      $subjectWithMarks = [];
      if ($subjectListByStdMedBoard) {
        $subjects = $subjectListByStdMedBoard['result'];
        if (!empty($subjects)) {
          foreach ($subjects as $subject) {
            $total_average = 0;
            $subject_marks = TestLineEntries::where('subjectCode', $subject['subjectCode'])
              ->whereHas('test_master', function ($query) use ($r) {
                $query->where('student_code', $r->student_code)
                  ->where('board_code', $r->board_code)
                  ->where('medium_code', $r->medium_code)
                  ->where('standard_code', $r->standard_code);
              });
            $total_subject_marks = $subject_marks->sum('queMarks');
            $total_subject_recieved_marks = $subject_marks->where('isCorrect', 'true')->sum('queMarks');
            if ($total_subject_marks !== 0) {
              $total_average = ($total_subject_recieved_marks / $total_subject_marks) * 100;
            }
            $total_average = number_format($total_average, 2);
            $subjectWithMarks[] = [
              'subject_code' => $subject['subjectCode'],
              'subject_name' => $subject['subjectName'],
              'received_marks' => $total_average
            ];
          }
        } else {
          return response()->json([
            'status' => 300,
            'message' => 'Data not found.',
          ], 200);
        }
      } else {
        return response()->json([
          'status' => 300,
          'message' => 'Data not found.',
        ], 200);
      }
      $data = [
        'subjectWithMarks' => $subjectWithMarks
      ];

      return response()->json(['status' => 200, 'message' => 'success', 'data' => $data], 200);
    } catch (\Exception $e) {
      return response()->json(['status' => 500, 'message' => 'Error: ' . $e->getMessage()], 500);
    }
  }

  public function get_student_test_result(Request $r)
  {
    // Check if the tenant_id header is present
    if (!$r->hasHeader('tenant-id')) {
      return response()->json([
        'status' => 400,
        'message' => 'tenant_id header is missing.',
      ], 400);
    }

    $rules = [
      'board_code' => 'required',
      'medium_code' => 'required',
      'standard_code' => 'required',
      'student_code' => 'required',
      'isSubject' => 'required|in:true,false',
      'subject_code' => 'required_if:isSubject,true',
      'testType' => 'nullable',
      'offset' => 'required',
    ];
    // Create a validator instance
    $validator = Validator::make($r->all(), $rules);
    // Check if the validation fails
    if ($validator->fails()) {
      return response()->json([
        'status' => 400,
        'error' => $validator->errors()->first(),
      ], 422);
    }

    try {
      // Retrieve tenant ID from the header
      $tenant_id = $r->header('tenant-id');
      $tenant = Tenant::find($tenant_id);
      if (!$tenant) {
        return response()->json(['message' => 'Tenant not found'], 404);
      }
      tenancy()->initialize($tenant);

      $board_id = $r->board_code;
      $medium_id = $r->medium_code;
      $standard_id = $r->standard_code;
      $student_id = $r->student_code;
      $subject_id = $r->subject_code ?? "0";
      $test_type = $r->testType;
      $isSubject = $r->isSubject;

      $result = TestMaster::with(['test_line_entries' => function ($query) use ($subject_id, $isSubject) {
        if ($isSubject == "true") {
          $query->where('subjectCode', $subject_id);
        }
      }])
        ->where('student_code', $student_id)
        ->where('board_code', $board_id)
        ->where('medium_code', $medium_id)
        ->where('standard_code', $standard_id);
      if ($test_type != "") {
        $result->where('test_type', $test_type);
      }
      if ($r->offset) {
        $result->skip($r->offset);
      }
      $test_list = $result->limit(10)->get();
      if (count($test_list) > 0) {
        return response()->json(['status' => 200, 'message' => 'success', 'data' => $test_list], 200);
      } else {
        return response()->json([
          'status' => 300,
          'message' => 'Data not found.',
          'data' => $test_list
        ], 200);
      }
    } catch (\Exception $e) {
      return response()->json(['status' => 500, 'message' => 'Error: ' . $e->getMessage()], 500);
    }
  }

  public function update_student_code(Request $r)
  {
    // Check if 'tenant-id' header is present
    if (!$r->hasHeader('tenant-id')) {
      return response()->json([
        'status' => 'error',
        'message' => 'tenant_id header is missing.',
      ], 400);
    }

    // Validate input
    $rules = [
      //'phone_number' => 'required', # orginal code mapped with phone number
      'email' => 'required|email', # mapped with email from 14-08-2024
      'student_code' => 'required',
      'board_code' => 'required',
      'medium_code' => 'required',
      'standard_code' => 'required',
    ];
    $messages = [
      //'phone_number.required' => 'Phone Number is required',  # orginal code mapped with phone number
      'email.required' => 'Email is Required', # mapped with email from 14-08-2024
      'email.email' => 'Invalid email format', # mapped with email from 14-08-2024
      'student_code.required' => 'Student Code is required',
      'board_code.required' => 'Board Code is required',
      'medium_code.required' => 'Medium Code is required',
      'standard_code.required' => 'Standard Code is required',
    ];
    $validator = Validator::make($r->all(), $rules, $messages);
    if ($validator->fails()) {
      return response()->json([
        'status' => 'error',
        'message' => $validator->errors()->first(),
      ]);
    }

    try {
      // Initialize tenant
      $tenant_id = $r->header('tenant-id');
      $tenant = Tenant::find($tenant_id);
      tenancy()->initialize($tenant);

      // On Till Dt. 13-08-2024
      // Check if student exists with phone number
      /*
      $existingStudent = SmStudent::where('mobile', $r->phone_number)->first();
      if (!$existingStudent) {
        return response()->json([
          'status' => 400,
          'message' => 'Student not found.',
        ], 300);
      }
      */

      // On Till Dt. 13-08-2024
      // Check if student code exists for another student
      /*
      $isStudentCodeExist = SmStudent::where('student_code', $r->student_code)
        ->where('mobile', '!=', $r->phone_number)
        ->exists();
      if ($isStudentCodeExist) {
        return response()->json([
          'status' => 400,
          'message' => 'This mobile number is already exists for another student.',
        ]);
      }
      */

      // Dt. 14-08-2024
      // Set every thing on email
      $student = SmStudent::where('email', $r->email)->first();
      if (!$student) {
        return response()->json([
          'status' => 400,
          'message' => 'Student not found.',
        ], 300);
      }

      if ($student->student_code != "" && $student->student_code != $r->student_code) {
        $student->student_code = $r->student_code;
      } else {
        $student->student_code = $r->student_code;
      }

      $student->student_code = $r->student_code;
      $student->board_code = $r->board_code;
      $student->medium_code = $r->medium_code;
      $student->standard_code = $r->standard_code;
      $student->save();
      return response()->json([
        'status' => 200,
        'message' => 'Student updated successfully.',
      ]);
    } catch (\Exception $e) {
      return response()->json(['message' => 'Error: ' . $e->getMessage()], 500);
    }
  }
}
