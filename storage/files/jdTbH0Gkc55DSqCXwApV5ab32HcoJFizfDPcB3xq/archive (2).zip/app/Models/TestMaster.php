<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TestMaster extends Model
{
    use HasFactory;

    protected $fillable = [
        'tenant_id',
        'board_code',
        'medium_code',
        'standard_code',
        'test_type',
        'test_name',
        'student_code',
        'total_marks',
        'start_time',
        'end_time',
        'exam_level',
        'received_marks',
        'answer_log',
    ];

    protected $casts = [
        'total_marks' => 'decimal:2',
        'received_marks' => 'decimal:2'
    ];

    public function test_line_entries()
    {
        return $this->hasMany(TestLineEntries::class, 'test_id', 'id');
    }
}
