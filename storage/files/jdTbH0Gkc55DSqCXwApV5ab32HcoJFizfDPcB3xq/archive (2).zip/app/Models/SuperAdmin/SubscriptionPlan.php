<?php

namespace App\Models\SuperAdmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubscriptionPlan extends Model
{
    use HasFactory;

    protected $fillable = ['id', 'title', 'cost_per_user', 'cost_per_project', 'no_of_user', 'no_of_project', 'duration_in_month', 'sub_total', 'tax_percentage', 'tax_amount', 'total_price', 'isactive', 'isdelete', 'created_at', 'updated_at'];
}
