<?php

namespace App\Models\SuperAdmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SchoolAccount extends Model
{
    use HasFactory;


    protected $fillable = [
        'tenant_id',
        'domain',
        'school_name',
        'full_name',
        'email',
        'phone',
        'address',
        'city',
        'state',
        'postalcode',
        'country',
        'logo',
        'favicon',
        'token',
        'is_email_verified',
        'active_status',
        'is_enabled',
        'school_subscription_id',
        'plan_expiry_date',
        'is_expired',
    ];
}
