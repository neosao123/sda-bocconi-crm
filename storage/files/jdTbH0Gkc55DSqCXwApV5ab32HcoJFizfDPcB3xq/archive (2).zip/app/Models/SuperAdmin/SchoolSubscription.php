<?php

namespace App\Models\SuperAdmin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SchoolSubscription extends Model
{
    use HasFactory;

    protected $table = 'schoolsubscription';

    protected $fillable = [
        'subscription_id',
        'school_id',
        'start_date',
        'end_date',
        'is_active',
        'is_delete',
        'add_id',
        'add_ip',
        'edit_id',
        'edit_ip',
        'delete_id',
        'delete_ip',
        'is_expired',
    ];
}
