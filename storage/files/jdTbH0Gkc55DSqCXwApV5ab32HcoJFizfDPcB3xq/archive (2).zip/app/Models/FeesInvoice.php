<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeesInvoice extends Model
{
    use HasFactory;

    protected $fillable = [
        'fees_type_id',
        'academic_year_id',
        'class_id',
        'section_id',
        'student_id',
        'description',
        'amount',
        'payment_mode',
        'reference_no',
        'invoice_date'
    ];

    public function feesType()
    {
        return $this->belongsTo('App\SmFeesType', 'fees_type_id', 'id');
    }
    public function academicYear()
    {
        return $this->belongsTo('App\SmAcademicYear', 'academic_year_id', 'id');
    }

    //student class name
    public function class()
    {
        return $this->belongsTo('App\SmClass', 'class_id', 'id');
    }

    public function section()
    {
        return $this->belongsTo('App\SmSection', 'section_id', 'id');
    }
    public function student()
    {
        return $this->belongsTo('App\SmStudent', 'student_id', 'id');
    }
}
