<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class SmQuestionBankMuOption extends Model
{
    use HasFactory;
}
